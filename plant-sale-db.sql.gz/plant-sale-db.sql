--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.1
-- Dumped by pg_dump version 9.5.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: docker
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE auth_group OWNER TO docker;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: docker
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_id_seq OWNER TO docker;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docker
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: docker
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_group_permissions OWNER TO docker;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: docker
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_permissions_id_seq OWNER TO docker;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docker
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: docker
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE auth_permission OWNER TO docker;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: docker
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_permission_id_seq OWNER TO docker;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docker
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: docker
--

CREATE TABLE authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE authtoken_token OWNER TO docker;

--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: docker
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE django_admin_log OWNER TO docker;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: docker
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin_log_id_seq OWNER TO docker;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docker
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: docker
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE django_content_type OWNER TO docker;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: docker
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_content_type_id_seq OWNER TO docker;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docker
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: docker
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE django_migrations OWNER TO docker;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: docker
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_migrations_id_seq OWNER TO docker;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docker
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: docker
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE django_session OWNER TO docker;

--
-- Name: plants_order; Type: TABLE; Schema: public; Owner: docker
--

CREATE TABLE plants_order (
    id integer NOT NULL,
    done boolean NOT NULL,
    stakeholder_id integer NOT NULL,
    charge_data character varying(100),
    charge_date timestamp with time zone
);


ALTER TABLE plants_order OWNER TO docker;

--
-- Name: plants_order_id_seq; Type: SEQUENCE; Schema: public; Owner: docker
--

CREATE SEQUENCE plants_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE plants_order_id_seq OWNER TO docker;

--
-- Name: plants_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docker
--

ALTER SEQUENCE plants_order_id_seq OWNED BY plants_order.id;


--
-- Name: plants_orderitem; Type: TABLE; Schema: public; Owner: docker
--

CREATE TABLE plants_orderitem (
    id integer NOT NULL,
    order_id integer NOT NULL,
    plant_id integer NOT NULL,
    color character varying(200),
    qty integer NOT NULL,
    updated timestamp with time zone NOT NULL
);


ALTER TABLE plants_orderitem OWNER TO docker;

--
-- Name: plants_orderitem_id_seq; Type: SEQUENCE; Schema: public; Owner: docker
--

CREATE SEQUENCE plants_orderitem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE plants_orderitem_id_seq OWNER TO docker;

--
-- Name: plants_orderitem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docker
--

ALTER SEQUENCE plants_orderitem_id_seq OWNED BY plants_orderitem.id;


--
-- Name: plants_plant; Type: TABLE; Schema: public; Owner: docker
--

CREATE TABLE plants_plant (
    id integer NOT NULL,
    name character varying(100),
    description character varying(255),
    cost double precision NOT NULL,
    color_limits character varying(255),
    color_preference boolean NOT NULL,
    notes character varying(255),
    sun character varying(100),
    type character varying(100),
    img_url character varying(255),
    marketing character varying(255)
);


ALTER TABLE plants_plant OWNER TO docker;

--
-- Name: plants_plant_id_seq; Type: SEQUENCE; Schema: public; Owner: docker
--

CREATE SEQUENCE plants_plant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE plants_plant_id_seq OWNER TO docker;

--
-- Name: plants_plant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docker
--

ALTER SEQUENCE plants_plant_id_seq OWNED BY plants_plant.id;


--
-- Name: plants_stakeholder; Type: TABLE; Schema: public; Owner: docker
--

CREATE TABLE plants_stakeholder (
    id integer NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    is_active boolean NOT NULL,
    is_staff boolean NOT NULL,
    name character varying(128),
    phone character varying(15),
    times character varying(128),
    volunteer boolean NOT NULL
);


ALTER TABLE plants_stakeholder OWNER TO docker;

--
-- Name: plants_stakeholder_id_seq; Type: SEQUENCE; Schema: public; Owner: docker
--

CREATE SEQUENCE plants_stakeholder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE plants_stakeholder_id_seq OWNER TO docker;

--
-- Name: plants_stakeholder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docker
--

ALTER SEQUENCE plants_stakeholder_id_seq OWNED BY plants_stakeholder.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: docker
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: docker
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: docker
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: docker
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: docker
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: docker
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: docker
--

ALTER TABLE ONLY plants_order ALTER COLUMN id SET DEFAULT nextval('plants_order_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: docker
--

ALTER TABLE ONLY plants_orderitem ALTER COLUMN id SET DEFAULT nextval('plants_orderitem_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: docker
--

ALTER TABLE ONLY plants_plant ALTER COLUMN id SET DEFAULT nextval('plants_plant_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: docker
--

ALTER TABLE ONLY plants_stakeholder ALTER COLUMN id SET DEFAULT nextval('plants_stakeholder_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docker
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docker
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can add permission	2	add_permission
5	Can change permission	2	change_permission
6	Can delete permission	2	delete_permission
7	Can add group	3	add_group
8	Can change group	3	change_group
9	Can delete group	3	delete_group
10	Can add content type	4	add_contenttype
11	Can change content type	4	change_contenttype
12	Can delete content type	4	delete_contenttype
13	Can add session	5	add_session
14	Can change session	5	change_session
15	Can delete session	5	delete_session
16	Can add cors model	6	add_corsmodel
17	Can change cors model	6	change_corsmodel
18	Can delete cors model	6	delete_corsmodel
19	Can add token	7	add_token
20	Can change token	7	change_token
21	Can delete token	7	delete_token
22	Can add plant	8	add_plant
23	Can change plant	8	change_plant
24	Can delete plant	8	delete_plant
25	Can add stakeholder	9	add_stakeholder
26	Can change stakeholder	9	change_stakeholder
27	Can delete stakeholder	9	delete_stakeholder
28	Can add order	10	add_order
29	Can change order	10	change_order
30	Can delete order	10	delete_order
31	Can add order item	11	add_orderitem
32	Can change order item	11	change_orderitem
33	Can delete order item	11	delete_orderitem
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docker
--

SELECT pg_catalog.setval('auth_permission_id_seq', 33, true);


--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY authtoken_token (key, created, user_id) FROM stdin;
30cc98217542e416f2adc34585637df0874fb9ad	2016-03-14 01:07:42.499258+00	1
00b1c98bd137628c9ca95972ab6c342460a42fa8	2016-03-21 16:50:30.574024+00	64
eddef812edfbc08885b2c90786ce162131e240e7	2016-03-23 02:42:16.695125+00	65
888c453a058ee024da1bf692800ebb6d9fbcbfa3	2016-03-24 01:50:59.148777+00	66
81fad095a3c47373aa366c58215ec8a552dd9597	2016-03-27 14:51:05.778554+00	69
04395c10ae02dfb04b2cc0dac351e06bec23dc4c	2016-03-27 22:57:27.457454+00	70
f00cdd7d67ddaa86f5e1a4a1138d51bcf8b56faa	2016-03-31 15:24:00.650059+00	71
2dd202381545c6dfa8702c52f44c725637b90f5d	2016-04-01 17:23:47.761643+00	72
4230eab345f6797c8e35f72343f5fdbc583a8605	2016-04-04 19:22:55.270607+00	74
e6bc7833eb241c49d0b01a23b4b467499d42597c	2016-04-04 23:31:55.076117+00	75
7dd2521fa768ac480ed250afa42d002eef413745	2016-04-05 03:25:56.441999+00	77
5fe52ffb1bee435aef551a0d03a77881754e1bb2	2016-04-05 15:16:02.538266+00	78
08094bae27dab55cabb083560508101138402cb4	2016-04-05 17:56:12.417343+00	79
819623c0395aa48f27bbb50f0cbe8083c41b8a82	2016-04-05 21:15:02.379231+00	80
0a642bcbd8733b83b6f275acf0a8d8907236b79b	2016-04-06 13:17:50.153688+00	81
de0a114f6331602f24b923ae9bf06d18abe701d1	2016-04-06 15:24:59.703423+00	83
a364cacc1745661f65a087e632d0fb81c7997e13	2016-04-06 15:25:40.801044+00	84
4a92c283aa637fe6cf1bd8f20ca107e559b13d71	2016-04-06 17:00:12.982305+00	86
bbac613954a740a9c1dc72a66c9f0579cc9a68e7	2016-04-06 19:15:54.283689+00	87
d06c006e6357c2a88a68e64d96e0b79d71ddf375	2016-04-06 20:11:30.129714+00	88
88deb14513ad3353239fa55db13aa05c4830d451	2016-04-06 22:38:13.879464+00	90
02ab11f572b437142597f17e1549ff615a373e38	2016-04-07 19:21:39.526201+00	92
f57ce074e16ce9121de0ca23f538d8a2d519486d	2016-04-08 02:58:23.214317+00	93
9f69aa34fefdc8c9435e63d03b057e65954425bf	2016-04-08 14:18:54.784307+00	95
78f74b02083bcd3105f594524819ba501e319cf5	2016-04-08 17:16:07.918276+00	99
ddfd45bd0967ccb26417b3af011f9b869cadf2b2	2016-04-08 17:34:52.714295+00	100
b4dc94a27bd2427e9cd7c4c524417c0a802cc6d9	2016-04-08 18:45:41.668836+00	101
f74e20c580a0b95c525e31fbe1b1ecb7da2f19ce	2016-04-09 01:50:05.690358+00	102
0a6380082e644e4fbe6dcad0b27275b30ff37409	2016-04-09 02:49:09.928578+00	103
59e385650a61c486071c35646614428f4b2a1a22	2016-04-09 15:52:07.395991+00	104
2bba52b93393d3646b7400dbc32f9254d0e66a42	2016-04-11 13:43:09.763388+00	105
72b5393376154f1e13f6fb2b6f8d04bd14fa8744	2016-04-11 17:39:21.689123+00	106
c322bbb44ce5140bec3d8348a0abb365a22b3655	2016-04-12 12:50:09.223262+00	107
4f3b4b10ea34bd6fcb9af361d8de79265e4d3a9d	2016-04-12 23:38:55.175579+00	109
48eb33b6d1ec65c2d2b41541bd9b9537e6574f5d	2016-04-12 23:56:26.557569+00	110
113ae1e561c36d39bff707cfd01fbe4e900d628b	2016-04-13 02:15:16.614351+00	112
8487c7b32569f5fd3bf3693383ae4f607eaf8b16	2016-04-13 04:47:32.899605+00	113
5c7f546fe700a88fec797e3ffee27169b9b2db0c	2016-04-13 13:18:52.429231+00	114
42a7df103d904a35be2f1f2910b6ab5caf51db26	2016-04-13 19:06:03.028189+00	117
c55e54ddb0223854df9f99f08e699b7d4fb67b54	2016-04-13 20:51:52.500358+00	118
3c095cacd52ef971f816492b0d2f6f218e2b55e1	2016-04-13 21:28:09.566365+00	119
c1f84a5f43af186f68618497b17dc590af681feb	2016-04-13 23:44:18.713788+00	120
e94fedac9cffd10d063d77ab2e055e2ccb459058	2016-04-14 00:09:38.091383+00	129
181a11c72883310fcef8f284b232fecb86defd78	2016-04-14 00:41:21.075594+00	130
f462f4b73ec8a860a90e2bb2af854754c7bd75a8	2016-04-14 00:43:58.17625+00	131
aeb1bd03ccc602dea24aa93e91e115d8a20d8135	2016-04-14 00:50:20.651212+00	132
51cdeaa3d88c3739538f104d87115a2122243a80	2016-04-14 00:54:47.157596+00	133
48f0641d3799d2c9e5b250ad8cf5d5ccf7ce648b	2016-04-14 00:57:06.143641+00	134
7f44b5b91395e3aff0803b1162a0840603212f30	2016-04-14 01:02:56.287573+00	135
d6070a60a5e3f646bcd692a01104a88cd748cc68	2016-04-14 01:04:26.156965+00	136
32fee197f0da14ad9175676f8d9f6f53392c7495	2016-04-14 01:10:15.579714+00	137
254ee445ca71197e868bebf955601db9bbdb1129	2016-04-14 01:15:08.424851+00	138
a15a47a8e6027ca13a841e7ebd608628fa9b15da	2016-04-14 01:18:31.407046+00	139
d33eaa469ce785ecea5ef16f5ef190aeed9a4e2b	2016-04-14 01:20:17.754022+00	140
380eac7f61913b2c689f693e3216f4ce38899235	2016-04-14 01:23:34.048524+00	141
08253933fcac534842c5e81b2a3c18784de2029a	2016-04-14 01:28:32.628029+00	142
45441a7ffb43c39b22a2c408af7d8e16e4131196	2016-04-14 01:30:18.552068+00	143
04ab845dfc7b54abba9a05879bce02b3ce8d7fcc	2016-04-14 01:33:46.410368+00	144
cb048a579dac81f0f03e313ed158e5eedbdcc2d2	2016-04-14 01:37:23.365174+00	145
8dd112b186b7b6543033b1bebaedd11e5c4e70ba	2016-04-14 01:48:38.230324+00	146
94e79fe7256204020a381e36abd996eb72dd06de	2016-04-14 01:49:58.686159+00	147
83e86d94c0a2e846c4df69aeaeb982834d5abdf2	2016-04-14 01:53:09.532748+00	148
d8f79fc1a9cafa9b8867c0fd1201e8d9d9ff27d6	2016-04-14 01:55:58.2873+00	149
351667e27b01cf6948204bc758e1cfb3891d471d	2016-04-14 02:00:30.03997+00	150
b63a6183d1cc2873f43ba442ec7db76726f7ee08	2016-04-14 02:02:36.918304+00	151
40296eaaa18a14d1c5b40af75570a17b7ae2c3ed	2016-04-14 02:05:37.440694+00	152
d7abff3cbef522e2fa09fcb7df359319a767f935	2016-04-14 02:22:49.178801+00	153
b552e0fdceee159aac00afc3ed6cc0918b83db31	2016-04-14 02:26:33.081604+00	154
ed49e175efe8cc54e7ea88904dc209eb1fdb367e	2016-04-14 02:31:10.128823+00	155
bda828d46770f093623721bf5a19cdba82e42c8d	2016-04-14 02:34:56.229921+00	156
39517139deb2742770a5f819eb19facb5fe3f289	2016-04-14 02:40:21.656694+00	157
0ce67dc00b1d94c8f1f1b892e3358919c83e6af9	2016-04-14 11:12:33.698746+00	158
6fcd04c3966715beda410b74bb3f8bb425897cd7	2016-04-14 18:35:30.049801+00	159
4b25e014894ce4c2ce57af59d2c3fcb00b42a08a	2016-04-15 01:56:23.373013+00	160
fd098f05ee357f1f8881873077e0300f73fdfb4c	2016-04-17 18:11:40.812749+00	163
57bc96f68a561e3ee250eae2654af245b01d2c61	2016-04-17 18:17:18.524689+00	164
7aef72ee125af7028032c51d638feebff55539fb	2016-04-17 18:25:06.801627+00	165
38b2b730d5d32c3582d915ba31d550ff3a4fa94d	2016-04-17 18:35:46.281684+00	166
91ade3ff175970a70769adb9d90b588803937676	2016-04-17 18:40:07.10053+00	167
82e4385751c4d7c9e233104010b0b25f09c60877	2016-04-17 18:47:28.116121+00	168
34e67e73851e0d40e1ac28d9f911418177cc3afe	2016-04-17 18:57:45.591112+00	169
66ffc46286e894bba90efd82a04046ede0c0ae0f	2016-04-17 19:01:39.260132+00	170
c087f5c344f51e63082c9335e53f8e8bfab37d40	2016-04-17 19:07:34.371727+00	171
a3e9eb978a945e4f20af0264141435575342c6ee	2016-04-18 00:31:04.671465+00	172
d6d799f9a9925cea615fa6ada76cf9d0b2156a65	2016-04-18 00:33:36.907695+00	173
07ce12e5c42ce4f254b5f560d4cb3df6772d367b	2016-04-18 01:34:37.979751+00	174
e9e7e310b3b8d818038997f5554e4e185f1fa1b1	2016-04-18 01:42:22.799933+00	175
cc5ffef9455a620f8d680aa9a13f02aa580cbd2e	2016-04-18 11:15:38.391124+00	176
35d191c74986ed55a11aeebce4cf7ede744c8063	2016-04-18 11:20:19.468972+00	177
e4ee8c2d7ee2749f91554c35dbaa84a47efb5f6d	2016-04-18 12:58:14.508263+00	178
310be39ff48d41106dc96a61f60e93e55c4e9646	2016-04-18 16:02:00.079977+00	179
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docker
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 1, false);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	contenttypes	contenttype
5	sessions	session
6	corsheaders	corsmodel
7	authtoken	token
8	plants	plant
9	plants	stakeholder
10	plants	order
11	plants	orderitem
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docker
--

SELECT pg_catalog.setval('django_content_type_id_seq', 11, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY django_migrations (id, app, name, applied) FROM stdin;
1	plants	0001_initial	2016-03-14 00:52:14.394696+00
2	contenttypes	0001_initial	2016-03-14 00:52:14.40861+00
3	admin	0001_initial	2016-03-14 00:52:14.438156+00
4	admin	0002_logentry_remove_auto_add	2016-03-14 00:52:14.450723+00
5	contenttypes	0002_remove_content_type_name	2016-03-14 00:52:14.474454+00
6	auth	0001_initial	2016-03-14 00:52:14.543968+00
7	auth	0002_alter_permission_name_max_length	2016-03-14 00:52:14.573612+00
8	auth	0003_alter_user_email_max_length	2016-03-14 00:52:14.585925+00
9	auth	0004_alter_user_username_opts	2016-03-14 00:52:14.598413+00
10	auth	0005_alter_user_last_login_null	2016-03-14 00:52:14.610832+00
11	auth	0006_require_contenttypes_0002	2016-03-14 00:52:14.613333+00
12	auth	0007_alter_validators_add_error_messages	2016-03-14 00:52:14.625745+00
13	authtoken	0001_initial	2016-03-14 00:52:14.648317+00
14	plants	0002_stakeholder_last_login	2016-03-14 00:52:14.671406+00
15	plants	0003_auto_20160309_0324	2016-03-14 00:52:14.813323+00
16	plants	0004_auto_20160309_1442	2016-03-14 00:52:14.838263+00
17	plants	0005_plant_marketing	2016-03-14 00:52:14.852687+00
18	plants	0006_auto_20160311_2116	2016-03-14 00:52:14.896212+00
19	plants	0007_auto_20160313_1932	2016-03-14 00:52:14.924594+00
20	plants	0008_auto_20160313_2015	2016-03-14 00:52:14.965021+00
21	sessions	0001_initial	2016-03-14 00:52:14.981732+00
22	plants	0009_auto_20160320_2254	2016-03-21 00:10:08.84084+00
23	authtoken	0002_auto_20160226_1747	2016-04-05 02:31:44.050569+00
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docker
--

SELECT pg_catalog.setval('django_migrations_id_seq', 23, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
0m73l3ceq31qif96m3i7iynv2d2wzte7	MTE4ZDc2MzJhOTMyN2E3MjQ3YWRhNDkxNGQwNmM1MjVkYzhmZDRlNDp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQifQ==	2016-03-30 19:13:59.346384+00
z6un38rk0d7q61ptwj3a1swkqsyarmuq	NWZmZjI1YjM5Zjc0MDc2Y2Y0OGExZjQ2NzU2NDMxM2RlMTFiYzkwMzp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjYzIn0=	2016-04-04 13:29:23.428886+00
b57ua82xgou3es0mq3beqnj5dwix3727	MzViMzhmOWRmOWY5NTUzY2FiMGNjODI1ZDIzMjZhMGRjMzRkNWE2MTp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjY1In0=	2016-04-06 20:11:21.422051+00
x2n2bp87ndlzupi0ndib7a0276mzxkvl	NDQ5OWIzYzhmZjQzNTA2NzU3M2VkMTQ4ZmVjNTQzZmM4MDRiMTZiZTp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjY4In0=	2016-04-07 17:54:43.095047+00
dhh0i0kx2vkugtsdd64s5j4mkerk7q1y	YWY2ODE5NjcyYmUyMjBkMmRiNDM0ZjJmZjViODkyYTU2NmE3NmMyMTp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjY0In0=	2016-04-17 03:01:07.544475+00
clnbznl8idnqcqhh9oe6qdhyfrscb5u6	MzViMzhmOWRmOWY5NTUzY2FiMGNjODI1ZDIzMjZhMGRjMzRkNWE2MTp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjY1In0=	2016-04-18 02:34:48.009821+00
z6mfxk1pntcmnuqw7pqf8y29ounkir9e	NmY5MzU1YzE3ZjRlMDFmODlkMmEwYWY0NTdhYzEzNjA2MjJjYzJhOTp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Ijc2In0=	2016-04-19 01:24:46.513519+00
6c19ycudpcbkttjepc7lkzco1cxywm0u	NDkwMDNiYjUwYTAxZWZhMTNhMDFkOWMyNTRmOTQyZGJmMGJmYjY3ODp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Ijc5In0=	2016-04-19 18:05:06.41087+00
lzf9v204ebik1zva7n7tuv68pjkuivvz	ZmViMDliMmM5MTdiZTU0ODU4YTY4MGViYzk3OWEyZjkyNWM4NGFiYTp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfaWQiOiI4MSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2016-04-20 14:23:19.484199+00
zep69084juwes4g4pbtlr0qkkyvnzix5	NGI2MDg3OWY1ZTZmYzI4NjJkMjIzZjBjMGZiY2EwNjdjYjQyOTZmYzp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfaWQiOiI2NCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2016-05-01 18:04:09.859658+00
kq7mekhhsw2src58r1ykxi6hfnj8ps6c	YWY2ODE5NjcyYmUyMjBkMmRiNDM0ZjJmZjViODkyYTU2NmE3NmMyMTp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjY0In0=	2016-05-01 18:07:12.41398+00
guptaifaneetl8xwmayucx04za278iub	ZGMzMjU2NjZkMjNiZjY5ODE2YTMwMTBiYzlkODY0MjM5NjMxMzEzNDp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfaWQiOiI4NCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2016-05-01 23:36:21.832+00
klpj6059zkuaerk1wtuutos8zy24au7s	MDk2ZmQ4ZGYwMjZlMTkyZmE1YWQwN2U1MzBiOGU0YTJmOTg0ZGY0NDp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjgwIn0=	2016-04-20 21:14:15.583532+00
ic6yntd4mymtnpgwo639p0xhu5gfscqd	OTVjMjc3MjJjMDRlYmE1ZjAzYzUzZTYyNDk1NDA2ZWQ0MjFmZTY4Njp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Ijc3In0=	2016-04-21 19:45:40.285821+00
5lxysldw8ulu71zljpdup5q53a5vaqg8	NWM3MGFhOTVhMGYxOTc1ZGRlMzhjZjlmM2QxZjgzMWJhYjcxOWJmMDp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfaWQiOiI3OCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2016-04-22 13:15:34.20185+00
7i0onbzirourvmw6v6pybd09wev4csox	ZTMzYzM0NGQ1ZGI4N2QwMDZjMjZiNjdiZDFhNGM3MGQ0MDI4N2QwYTp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfaWQiOiI5NSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2016-04-22 15:03:18.865025+00
g53haa13ppjzvv22127k6waov7rxn1ld	MzFkYTEyYmVjMWM4OGNiYTYxMmQ3YzMwZGNiMjhlNTZiOTM2NWVjYTp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjEwOSJ9	2016-04-27 00:10:51.279245+00
646cgpedsxtraejt3ug64qa0qcj0n0eu	ZjE1Yjg3ZDM5YWUzYzc4MWQ4Mjg0MTJmOWMxOGYzZjY0OThlY2U3MDp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjEwNiJ9	2016-04-27 15:51:20.962301+00
9xe7x6tkvxla0w9mqsl90f6mty5qam9z	YTZlYmI4MmE5ZDI2ZTQ3MGY3YzU1ZTFiNGFjNDNjMDQxYzJlMTkyZTp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjExMCJ9	2016-04-27 18:24:49.930273+00
a2hq9vu94ztgejjisyhplk85f3pihcy7	YTYwNGRhNzNlOGM3N2U0N2ExYTk4YmMzMzk2MTA5NDljY2MxZDMzZjp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Ijg0In0=	2016-05-03 10:57:11.029311+00
6i9x0qxtnu7wi5bzyu1oxhaowphp8liq	ZGZjNTAwOWExMWU3NzY1ODQ3YmFhODZkYWMxYjE3MGMwNjBhODFmZTp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjEyMCJ9	2016-04-27 23:48:57.351224+00
cb6rtoj995eeed1qodbu7iban8am781q	NGI2MDg3OWY1ZTZmYzI4NjJkMjIzZjBjMGZiY2EwNjdjYjQyOTZmYzp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfaWQiOiI2NCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2016-04-27 23:52:43.096881+00
9jk2we2wcp38on454m2hh3o9l2af4win	YTYwNGRhNzNlOGM3N2U0N2ExYTk4YmMzMzk2MTA5NDljY2MxZDMzZjp7Il9hdXRoX3VzZXJfaGFzaCI6IiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Ijg0In0=	2016-04-28 01:48:20.364711+00
\.


--
-- Data for Name: plants_order; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY plants_order (id, done, stakeholder_id, charge_data, charge_date) FROM stdin;
83	t	118	Check 2606	\N
98	t	141	Check 15966, 5300	\N
93	t	136	Check 7803	\N
110	t	153	Check 2354	\N
37	f	1	\N	\N
100	t	143	Check 2414	\N
105	t	148	Check 1357	\N
108	t	151	Check 1135	\N
112	t	155	Check 3648	\N
111	t	154	Check 2167	\N
44	t	69	succeeded	2016-03-27 14:58:32.181346+00
45	t	70	succeeded	2016-03-27 22:59:42.920028+00
46	t	71	succeeded	2016-03-31 15:32:07.434876+00
47	t	72	succeeded	2016-04-01 17:53:53.011686+00
41	t	65	succeeded	2016-04-04 02:37:01.704318+00
48	t	74	succeeded	2016-04-04 19:37:44.032811+00
49	t	75	succeeded	2016-04-04 23:57:29.895188+00
55	t	81	succeeded	2016-04-06 13:26:46.783475+00
58	t	86	succeeded	2016-04-06 17:51:44.120079+00
59	t	87	succeeded	2016-04-06 19:49:32.452672+00
54	t	80	succeeded	2016-04-06 21:15:40.368941+00
61	f	90	\N	\N
60	t	88	succeeded	2016-04-06 23:33:13.342121+00
109	t	152	Check 3073	\N
63	t	92	succeeded	2016-04-07 19:45:20.469022+00
51	t	77	succeeded	2016-04-07 19:47:27.610801+00
64	t	93	succeeded	2016-04-08 03:00:06.599443+00
52	t	78	succeeded	2016-04-08 13:14:37.099318+00
96	t	139	Pd Cash	\N
68	t	99	succeeded	2016-04-08 17:22:05.239167+00
69	f	100	\N	\N
72	t	103	succeeded	2016-04-09 02:56:13.665112+00
73	t	104	succeeded	2016-04-09 17:43:52.993754+00
42	t	66	succeeded	2016-04-12 01:07:27.451057+00
76	f	107	\N	\N
77	t	109	succeeded	2016-04-13 00:06:05.737507+00
80	f	113	\N	\N
81	t	114	succeeded	2016-04-13 13:37:24.517367+00
75	t	106	succeeded	2016-04-13 16:13:16.866972+00
53	t	79	succeeded	2016-04-13 17:39:55.783557+00
78	t	110	succeeded	2016-04-13 18:25:52.886627+00
82	t	117	succeeded	2016-04-13 19:10:56.732597+00
84	t	119	succeeded	2016-04-13 21:34:29.347559+00
40	t	64	succeeded	2016-04-14 00:01:02.068724+00
115	t	158	succeeded	2016-04-14 11:23:52.664079+00
118	f	163	\N	\N
126	f	171	\N	\N
128	t	173	Check 6280 St. Tims	\N
127	t	172	Check 2806 St.Tims	\N
86	t	129	Check 1368	\N
87	t	130	Check 2282	\N
88	t	131	Check 1472	\N
89	t	132	Check 1935	\N
90	t	133	Check 3410	\N
91	t	134	Check 1972	\N
92	t	135	Check 0928	\N
94	t	137	CHeck 5320	\N
95	t	138	Check 4030	\N
97	t	140	Check 2569	\N
99	t	142	Check 1576 & 1192	\N
101	t	144	Check 3021	\N
103	t	146	Check 4734	\N
104	t	147	Check 1231	\N
106	t	149	Check 14517	\N
107	t	150	Check 1560, 1564	\N
102	t	145	cash; short 4$	\N
85	t	120	Check 1568	\N
113	t	156	Check 1938	\N
114	t	157	Check 4947	\N
133	t	178	succeeded	2016-04-18 13:01:42.54314+00
56	t	83	succeeded	2016-04-18 13:27:48.135703+00
132	t	177	succeeded	2016-04-18 13:28:39.328974+00
131	t	176	succeeded	2016-04-18 13:29:16.586753+00
129	t	174	null	\N
57	t	84	null	\N
130	t	175	null	\N
71	t	102	null	\N
116	t	159	null	\N
117	t	160	null	\N
70	t	101	null void	\N
74	t	105	null void	\N
79	t	112	Check 1906, short 4$	\N
119	t	164	Check 2221	\N
120	t	165	Check 2000	\N
121	t	166	Check 1985	\N
122	t	167	CHeck 1566	\N
123	t	168	Check 5049 for 119$/132	\N
124	t	169	Check 1027	\N
125	t	170	Check 4644	\N
65	t	95	Null	\N
134	f	179	\N	\N
\.


--
-- Name: plants_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docker
--

SELECT pg_catalog.setval('plants_order_id_seq', 134, true);


--
-- Data for Name: plants_orderitem; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY plants_orderitem (id, order_id, plant_id, color, qty, updated) FROM stdin;
278	41	28	Bronze Leaf Red	0	2016-03-23 02:56:31.055518+00
280	41	28	Bronze Leaf Mixed	0	2016-03-23 02:56:31.072321+00
282	41	28	Bronze Leaf White	0	2016-03-23 02:56:31.087387+00
284	41	28	Green Leaf White	0	2016-03-23 02:56:31.434368+00
695	56	6	Go-Go Begonia-red w/creeping jenny or yellow w/silver dichondra	0	2016-04-06 15:25:43.006622+00
929	70	52	Violet (Hot Pink)	0	2016-04-08 18:48:35.410517+00
289	41	34	Orange	0	2016-03-23 02:57:47.138036+00
291	41	34	Vanilla (Sweet Cream)	1	2016-03-23 02:58:00.723339+00
292	41	60	Beefsteak	0	2016-03-23 02:58:20.573412+00
294	41	60	Big Boy	0	2016-03-23 02:58:20.582907+00
296	41	59	Green Bell	0	2016-03-23 02:58:43.757706+00
298	41	59	Red Bell	0	2016-03-23 02:58:43.766831+00
303	41	61	Thyme	0	2016-03-23 02:59:11.120707+00
301	41	61	Basil (Sweet Italian)	1	2016-03-23 02:59:20.257243+00
305	41	61	Oregano (Italian)	1	2016-03-23 02:59:27.918755+00
775	63	1	\N	3	2016-04-07 19:39:22.280616+00
931	70	52	White	0	2016-04-08 18:48:35.534422+00
933	70	5	Geranium w spike (white, magenta, pink, or coral)	0	2016-04-08 18:51:10.633406+00
935	70	5	Wave petunia mix - red, white, and dark purple	0	2016-04-08 18:51:10.753182+00
955	72	41	Dwarf Mixed	2	2016-04-09 02:50:50.563874+00
999	74	2	\N	0	2016-04-11 13:56:25.60466+00
912	69	52	Deep Red	0	2016-04-08 17:38:37.887486+00
33	37	3	\N	1	2016-03-14 15:07:45.343091+00
34	37	4	\N	1	2016-03-14 15:07:48.105952+00
35	37	5	Geranium w spike (white, magenta, pink, or coral)	0	2016-03-14 15:08:04.853643+00
36	37	5	Wave petunia mix - red, white, and dark purple	0	2016-03-14 15:08:04.893014+00
37	37	5	or Gerbera Daisy mix	0	2016-03-14 15:08:04.895023+00
38	37	6	New Guinea Impatiens (lavender or magenta)	0	2016-03-14 15:08:19.946608+00
39	37	6	or Begonia (big)--red	0	2016-03-14 15:08:19.949994+00
40	37	6	Go-Go Begonia-red w/creeping jenny or yellow w/silver dichondra	0	2016-03-14 15:08:19.956391+00
41	37	58	Red Wave	0	2016-03-14 15:09:14.086318+00
42	37	58	Blue Wave (Dark purple)	0	2016-03-14 15:09:14.087847+00
43	37	58	Pink Wave	0	2016-03-14 15:09:14.096188+00
44	37	58	White Wave	0	2016-03-14 15:09:14.110456+00
45	37	58	Purple Wave (Magenta)	0	2016-03-14 15:09:14.114754+00
46	37	61	Cilantro	0	2016-03-14 15:09:35.717356+00
47	37	61	Parsley	0	2016-03-14 15:09:35.721975+00
48	37	61	Thyme	0	2016-03-14 15:09:35.729911+00
49	37	61	Dill	0	2016-03-14 15:09:35.734721+00
50	37	61	Basil (Sweet Italian)	0	2016-03-14 15:09:35.740749+00
51	37	61	Oregano (Italian)	0	2016-03-14 15:09:35.745015+00
52	37	61	Mint	0	2016-03-14 15:09:35.769123+00
55	37	7	\N	1	2016-03-14 15:14:21.683771+00
56	37	8	\N	1	2016-03-14 15:14:31.105501+00
57	37	9	\N	1	2016-03-14 15:15:10.293545+00
58	37	10	\N	1	2016-03-14 15:15:32.514116+00
59	37	11	\N	1	2016-03-14 15:16:37.009633+00
60	37	12	\N	1	2016-03-14 15:16:45.757116+00
61	37	13	\N	1	2016-03-14 15:17:26.792531+00
62	37	14	\N	1	2016-03-14 15:17:45.695615+00
63	37	15	\N	1	2016-03-14 15:17:59.154326+00
64	37	16	\N	1	2016-03-14 15:18:21.324038+00
65	37	17	\N	1	2016-03-14 15:18:30.123062+00
66	37	18	\N	1	2016-03-14 15:18:52.617448+00
67	37	19	\N	1	2016-03-14 15:19:13.787921+00
68	37	20	\N	1	2016-03-14 15:19:36.666299+00
69	37	21	\N	1	2016-03-14 15:20:13.0313+00
70	37	22	\N	1	2016-03-14 15:20:37.260277+00
71	37	23	\N	1	2016-03-14 15:20:53.269965+00
72	37	24	\N	1	2016-03-14 15:21:10.166088+00
73	37	25	\N	1	2016-03-14 15:21:24.870763+00
74	37	26	Blue Pearl (pastel lt.purple)	0	2016-03-14 15:21:49.445367+00
75	37	26	Pink	0	2016-03-14 15:21:49.477732+00
76	37	26	Salmon	0	2016-03-14 15:21:49.484731+00
77	37	26	Red	0	2016-03-14 15:21:49.491095+00
78	37	26	Lilac (deep purple/pink)	0	2016-03-14 15:21:49.497327+00
79	37	26	Lipstick (Hot Pink)	0	2016-03-14 15:21:49.503872+00
80	37	26	Violet (dk. violet/purple)	0	2016-03-14 15:21:49.50844+00
81	37	26	White	0	2016-03-14 15:21:49.53745+00
82	37	26	Mixed	0	2016-03-14 15:21:49.542196+00
83	37	27	White	0	2016-03-14 15:22:22.586813+00
84	37	27	Purple	0	2016-03-14 15:22:22.590016+00
85	37	51	\N	1	2016-03-14 15:22:52.963106+00
86	37	52	Deep Red	0	2016-03-14 15:23:43.525662+00
87	37	52	Violet (Hot Pink)	0	2016-03-14 15:23:43.559801+00
88	37	52	White	0	2016-03-14 15:23:43.568579+00
89	37	52	Pink	0	2016-03-14 15:23:43.57182+00
90	37	56	Purple	0	2016-03-14 15:26:13.879539+00
91	37	56	Pink	0	2016-03-14 15:26:13.884866+00
92	37	56	White	0	2016-03-14 15:26:13.893059+00
93	37	56	Yellow	0	2016-03-14 15:26:13.897364+00
94	37	56	Red	0	2016-03-14 15:26:13.902735+00
95	37	57	Mixed	0	2016-03-14 15:26:38.908711+00
96	37	59	Green Bell	0	2016-03-14 15:26:56.575067+00
97	37	59	Jalapeno	0	2016-03-14 15:26:56.583071+00
98	37	59	Yellow Bell	0	2016-03-14 15:26:56.586879+00
99	37	59	Red Bell	0	2016-03-14 15:26:56.591753+00
100	37	60	Beefsteak	0	2016-03-14 15:27:10.459762+00
101	37	60	Big Boy	0	2016-03-14 15:27:10.468039+00
102	37	60	Roma	0	2016-03-14 15:27:10.469942+00
103	37	60	Sweet 100 (cherry tomatoes)	0	2016-03-14 15:27:10.480141+00
53	37	1	\N	0	2016-03-16 19:14:28.458283+00
54	37	2	\N	0	2016-03-16 19:14:32.254309+00
104	37	11	\N	1	2016-03-16 19:20:26.153738+00
105	37	12	\N	1	2016-03-16 19:20:26.734635+00
106	37	16	\N	1	2016-03-16 19:20:29.424681+00
107	37	21	\N	1	2016-03-16 19:20:35.351275+00
914	69	52	White	0	2016-04-08 17:38:37.963027+00
987	73	27	White	1	2016-04-09 16:27:53.534015+00
751	61	25	\N	1	2016-04-06 22:40:44.012332+00
753	61	26	Lilac (deep purple/pink)	0	2016-04-06 22:40:56.541834+00
755	61	26	White	0	2016-04-06 22:40:56.612299+00
757	61	26	Pink	0	2016-04-06 22:40:56.651753+00
759	61	26	Salmon	0	2016-04-06 22:40:56.664107+00
1022	74	26	Blue Pearl (pastel lt.purple)	0	2016-04-11 13:46:23.021265+00
1026	74	26	Red	0	2016-04-11 13:46:23.156369+00
1028	74	26	Violet (dk. violet/purple)	0	2016-04-11 13:46:23.167892+00
221	37	61	Dill	0	2016-03-16 19:37:57.129092+00
222	37	61	Parsley	0	2016-03-16 19:37:57.135082+00
223	37	61	Basil (Sweet Italian)	0	2016-03-16 19:37:57.141635+00
224	37	61	Cilantro	0	2016-03-16 19:37:57.149522+00
225	37	61	Thyme	0	2016-03-16 19:37:57.152323+00
226	37	61	Oregano (Italian)	0	2016-03-16 19:37:57.158382+00
227	37	61	Mint	0	2016-03-16 19:37:57.178271+00
694	56	6	New Guinea Impatiens (lavender or magenta)	0	2016-04-06 15:25:42.962907+00
696	56	6	or Begonia (big)--red	0	2016-04-06 15:25:43.045239+00
745	59	24	\N	1	2016-04-06 19:22:09.553521+00
279	41	28	Bronze Leaf Rose/Pink	0	2016-03-23 02:56:31.06621+00
281	41	28	Green Leaf Red	0	2016-03-23 02:56:31.075752+00
283	41	28	Green Leaf Rose/Pink	0	2016-03-23 02:56:31.430739+00
752	61	26	Blue Pearl (pastel lt.purple)	0	2016-04-06 22:40:56.536316+00
295	41	60	Sweet 100 (cherry tomatoes)	0	2016-03-23 02:58:20.630256+00
427	44	60	Big Boy	0	2016-03-27 14:56:22.220406+00
293	41	60	Roma	1	2016-03-23 02:58:40.090107+00
299	41	59	Jalapeno	0	2016-03-23 02:58:43.828363+00
297	41	59	Yellow Bell	1	2016-03-23 02:59:01.030594+00
302	41	61	Parsley	0	2016-03-23 02:59:10.769668+00
304	41	61	Dill	0	2016-03-23 02:59:11.122666+00
306	41	61	Mint	0	2016-03-23 02:59:11.139796+00
300	41	61	Cilantro	1	2016-03-23 02:59:17.143229+00
290	41	34	Yellow	1	2016-03-23 03:01:39.275841+00
285	41	28	Green Leaf Mixed	2	2016-03-23 03:02:50.166577+00
429	44	60	Sweet 100 (cherry tomatoes)	0	2016-03-27 14:56:22.233133+00
433	45	26	Lipstick (Hot Pink)	0	2016-03-27 22:58:08.653482+00
435	45	26	Red	0	2016-03-27 22:58:08.665898+00
437	45	26	Violet (dk. violet/purple)	0	2016-03-27 22:58:08.677367+00
439	45	26	Mixed	0	2016-03-27 22:58:08.723473+00
431	45	26	Blue Pearl (pastel lt.purple)	1	2016-03-27 22:58:13.328297+00
441	45	60	Roma	0	2016-03-27 22:58:22.015493+00
443	45	60	Sweet 100 (cherry tomatoes)	1	2016-03-27 22:58:27.959134+00
445	46	12	\N	2	2016-03-31 15:25:32.956627+00
446	46	26	Blue Pearl (pastel lt.purple)	0	2016-03-31 15:26:33.881+00
448	46	26	Pink	0	2016-03-31 15:26:33.928231+00
450	46	26	Lipstick (Hot Pink)	0	2016-03-31 15:26:33.939393+00
591	51	3	\N	3	2016-04-07 19:44:48.600678+00
776	63	13	Dark Red	5	2016-04-07 19:39:14.694445+00
754	61	26	Violet (dk. violet/purple)	0	2016-04-06 22:40:56.60842+00
792	65	41	Dwarf Mixed	0	2016-04-08 14:19:34.026241+00
1401	79	58	Pink Wave	0	2016-04-13 02:16:16.312671+00
932	70	52	Pink	0	2016-04-08 18:48:35.545338+00
756	61	26	Lipstick (Hot Pink)	0	2016-04-06 22:40:56.64084+00
452	46	26	Violet (dk. violet/purple)	0	2016-03-31 15:26:33.95257+00
454	46	26	Mixed	2	2016-03-31 15:26:40.186243+00
455	46	30	\N	1	2016-03-31 15:26:52.778565+00
459	46	39	Pink	0	2016-03-31 15:27:06.299017+00
461	46	39	Red	0	2016-03-31 15:27:06.312852+00
457	46	39	Mixed	1	2016-03-31 15:27:13.000472+00
463	46	41	Tall Mixed	1	2016-03-31 15:28:30.738318+00
408	44	59	Green Bell	0	2016-03-27 14:51:56.703645+00
410	44	59	Red Bell	0	2016-03-27 14:51:58.69872+00
758	61	26	Red	0	2016-04-06 22:40:56.663253+00
760	61	26	Mixed	0	2016-04-06 22:40:56.680448+00
956	72	41	Tall Mixed	0	2016-04-09 02:50:44.475231+00
540	49	33	Bonanza Bee (Yellow-orange)	0	2016-04-04 23:44:15.848998+00
542	49	33	Bonanza Orange	0	2016-04-04 23:44:15.940194+00
470	47	61	Basil (Sweet Italian)	2	2016-04-01 17:33:09.483235+00
612	52	5	Wave petunia mix - red, white, and dark purple	0	2016-04-05 15:22:44.089207+00
468	47	61	Cilantro	1	2016-04-01 17:33:25.558736+00
472	47	61	Mint	1	2016-04-01 17:33:30.567014+00
474	47	61	Oregano (Italian)	1	2016-04-01 17:34:46.247734+00
545	49	3	\N	1	2016-04-04 23:45:59.080689+00
554	49	18	\N	1	2016-04-04 23:53:47.680771+00
556	49	22	\N	1	2016-04-04 23:53:51.679589+00
479	47	33	Bonanza Bee (Yellow-orange)	0	2016-04-01 17:43:51.821667+00
481	47	33	Bonanza Yellow	0	2016-04-01 17:43:51.840562+00
617	53	60	Sweet 100 (cherry tomatoes)	0	2016-04-05 17:57:18.587606+00
464	47	60	Roma	2	2016-04-01 17:49:23.92203+00
466	47	60	Beefsteak	4	2016-04-01 17:49:55.576329+00
485	49	60	Beefsteak	0	2016-04-04 23:35:37.950727+00
488	49	60	Sweet 100 (cherry tomatoes)	0	2016-04-04 23:35:37.964888+00
492	49	61	Dill	0	2016-04-04 23:36:17.326665+00
494	49	61	Oregano (Italian)	0	2016-04-04 23:36:17.348175+00
490	49	61	Basil (Sweet Italian)	1	2016-04-04 23:38:15.416482+00
645	54	59	Jalapeno	1	2016-04-06 12:20:59.352548+00
528	49	26	Lilac (deep purple/pink)	0	2016-04-04 23:42:57.203774+00
530	49	26	Blue Pearl (pastel lt.purple)	0	2016-04-04 23:42:57.213506+00
532	49	26	Red	0	2016-04-04 23:42:57.260172+00
534	49	26	Violet (dk. violet/purple)	0	2016-04-04 23:42:57.303608+00
536	49	26	Mixed	0	2016-04-04 23:42:57.315012+00
544	49	44	Mixed	1	2016-04-05 02:40:31.543078+00
615	53	60	Roma	1	2016-04-05 17:57:30.504963+00
618	53	26	Blue Pearl (pastel lt.purple)	0	2016-04-05 17:58:15.520349+00
620	53	26	Lilac (deep purple/pink)	0	2016-04-05 17:58:15.531562+00
609	52	51	\N	5	2016-04-05 15:22:00.54625+00
622	53	26	Red	0	2016-04-05 17:58:15.597688+00
626	53	26	White	0	2016-04-05 17:58:15.710269+00
624	53	26	Mixed	1	2016-04-05 17:59:46.200021+00
629	53	61	Parsley	0	2016-04-05 18:00:01.635251+00
631	53	61	Dill	0	2016-04-05 18:00:01.650084+00
633	53	61	Thyme	0	2016-04-05 18:00:22.541529+00
638	54	23	\N	2	2016-04-05 21:52:55.24789+00
641	54	1	\N	6	2016-04-06 12:20:27.137446+00
642	54	59	Green Bell	0	2016-04-06 12:20:45.043+00
644	54	59	Red Bell	0	2016-04-06 12:20:45.105876+00
648	54	60	Big Boy	0	2016-04-06 12:21:13.502899+00
649	54	60	Sweet 100 (cherry tomatoes)	0	2016-04-06 12:21:13.507735+00
646	54	60	Beefsteak	1	2016-04-06 12:21:19.322215+00
647	54	60	Roma	1	2016-04-06 12:21:22.310464+00
650	54	61	Cilantro	0	2016-04-06 12:21:43.043623+00
651	54	61	Parsley	0	2016-04-06 12:21:43.045729+00
653	54	61	Dill	0	2016-04-06 12:21:43.102851+00
654	54	61	Thyme	0	2016-04-06 12:21:43.111759+00
655	54	61	Oregano (Italian)	0	2016-04-06 12:21:43.116739+00
656	54	61	Mint	0	2016-04-06 12:21:43.171016+00
652	54	61	Basil (Sweet Italian)	1	2016-04-06 12:21:49.237245+00
657	55	24	\N	3	2016-04-06 13:18:40.925448+00
658	55	28	Bronze Leaf Red	0	2016-04-06 13:18:58.279879+00
659	55	28	Bronze Leaf Rose/Pink	0	2016-04-06 13:18:58.285893+00
660	55	28	Bronze Leaf White	0	2016-04-06 13:18:58.339517+00
663	55	28	Green Leaf Rose/Pink	0	2016-04-06 13:18:58.408884+00
664	55	28	Green Leaf White	0	2016-04-06 13:18:58.460437+00
661	55	28	Bronze Leaf Mixed	1	2016-04-06 13:19:07.53445+00
662	55	28	Green Leaf Red	1	2016-04-06 13:19:18.034364+00
665	55	28	Green Leaf Mixed	1	2016-04-06 13:19:24.40613+00
666	55	29	\N	1	2016-04-06 13:19:34.582945+00
699	56	33	Bonanza Orange	0	2016-04-06 17:38:43.051771+00
701	56	37	\N	1	2016-04-06 17:38:49.074246+00
746	59	25	\N	2	2016-04-06 19:44:50.050721+00
934	70	5	or Gerbera Daisy mix	0	2016-04-08 18:51:10.740855+00
777	64	25	\N	2	2016-04-08 02:58:49.583993+00
778	64	59	Yellow Bell	0	2016-04-08 02:59:01.581918+00
780	64	59	Red Bell	0	2016-04-08 02:59:02.703228+00
768	63	16	Red/Pink	3	2016-04-07 19:26:19.118701+00
783	64	60	Beefsteak	0	2016-04-08 02:59:11.749345+00
785	64	60	Sweet 100 (cherry tomatoes)	0	2016-04-08 02:59:11.76337+00
771	63	22	\N	3	2016-04-07 19:29:58.088808+00
793	65	41	Tall Mixed	0	2016-04-08 14:19:34.031628+00
255	40	13	pink	0	2016-04-08 14:24:26.419248+00
268	41	26	Lilac (deep purple/pink)	1	2016-03-23 02:56:18.38484+00
270	41	26	Pink	1	2016-03-23 02:56:21.556581+00
426	44	1	\N	1	2016-03-27 14:53:48.626509+00
428	44	60	Beefsteak	0	2016-03-27 14:56:22.228404+00
267	41	26	Blue Pearl (pastel lt.purple)	1	2016-03-23 03:02:55.830835+00
264	41	6	Go-Go Begonia-red w/creeping jenny or yellow w/silver dichondra	0	2016-03-23 02:54:21.653487+00
265	41	6	or Begonia (big)--red	0	2016-03-23 02:54:21.658111+00
307	41	40	Red	0	2016-03-23 03:03:17.560918+00
263	41	6	New Guinea Impatiens (lavender or magenta)	1	2016-03-23 02:55:47.573607+00
269	41	26	Lipstick (Hot Pink)	0	2016-03-23 02:56:07.263356+00
271	41	26	Red	0	2016-03-23 02:56:07.274828+00
272	41	26	Salmon	0	2016-03-23 02:56:07.289049+00
273	41	26	Violet (dk. violet/purple)	0	2016-03-23 02:56:07.293766+00
274	41	26	White	0	2016-03-23 02:56:07.570556+00
430	44	60	Roma	1	2016-03-27 14:56:27.680695+00
434	45	26	Pink	0	2016-03-27 22:58:08.659143+00
314	41	44	Mixed	1	2016-03-23 03:03:41.028368+00
275	41	26	Mixed	1	2016-03-23 03:04:35.362761+00
315	41	40	Red	0	2016-03-23 03:05:54.018587+00
436	45	26	Salmon	0	2016-03-27 22:58:08.675947+00
262	41	14	pink	2	2016-03-23 03:07:21.092035+00
438	45	26	White	0	2016-03-27 22:58:08.716049+00
432	45	26	Lilac (deep purple/pink)	1	2016-03-27 22:58:14.222578+00
442	45	60	Big Boy	0	2016-03-27 22:58:22.020057+00
440	45	60	Beefsteak	1	2016-03-27 22:58:25.77524+00
444	45	24	\N	1	2016-03-27 22:59:11.043155+00
447	46	26	Lilac (deep purple/pink)	0	2016-03-31 15:26:33.89145+00
449	46	26	Red	0	2016-03-31 15:26:33.932877+00
909	69	3	\N	2	2016-04-08 17:38:07.884936+00
396	42	23	\N	2	2016-04-12 01:05:48.871618+00
911	69	52	Violet (Hot Pink)	0	2016-04-08 17:38:37.885964+00
913	69	52	Pink	0	2016-04-08 17:38:37.895473+00
1400	79	58	Red Wave	0	2016-04-13 02:16:16.28814+00
917	69	51	\N	1	2016-04-08 17:38:47.685949+00
1402	79	58	Purple Wave (Magenta)	0	2016-04-13 02:16:16.319915+00
451	46	26	Salmon	0	2016-03-31 15:26:33.943008+00
453	46	26	White	0	2016-03-31 15:26:33.956909+00
456	46	39	White	0	2016-03-31 15:27:06.281518+00
458	46	39	Purple	0	2016-03-31 15:27:06.294343+00
460	46	39	Yellow	0	2016-03-31 15:27:06.302275+00
462	46	41	Dwarf Mixed	0	2016-03-31 15:28:25.207538+00
465	47	60	Big Boy	2	2016-04-01 17:31:47.854286+00
409	44	59	Jalapeno	0	2016-03-27 14:51:58.692793+00
411	44	59	Yellow Bell	1	2016-03-27 14:52:09.867842+00
469	47	61	Parsley	2	2016-04-01 17:33:03.326248+00
471	47	61	Dill	1	2016-04-01 17:33:15.418539+00
419	44	4	\N	1	2016-03-27 14:53:19.51772+00
986	73	27	Purple	0	2016-04-09 16:26:28.999237+00
473	47	61	Thyme	1	2016-04-01 17:34:49.992187+00
480	47	33	Bonanza Orange	0	2016-04-01 17:43:51.833984+00
482	47	33	Bonanza Mixed	0	2016-04-01 17:43:51.845354+00
467	47	60	Sweet 100 (cherry tomatoes)	2	2016-04-01 17:50:47.249282+00
510	49	32	Blue	1	2016-04-04 23:42:11.53164+00
484	48	20	\N	2	2016-04-04 19:27:45.391011+00
486	49	60	Roma	0	2016-04-04 23:35:37.951561+00
489	49	61	Cilantro	0	2016-04-04 23:36:17.305481+00
491	49	61	Parsley	0	2016-04-04 23:36:17.317673+00
493	49	61	Thyme	0	2016-04-04 23:36:17.329479+00
1023	74	26	Lilac (deep purple/pink)	0	2016-04-11 13:46:23.063341+00
1025	74	26	Pink	0	2016-04-11 13:46:23.150347+00
531	49	26	Pink	0	2016-04-04 23:42:57.25244+00
533	49	26	Salmon	0	2016-04-04 23:42:57.264823+00
535	49	26	White	0	2016-04-04 23:42:57.310285+00
1027	74	26	Salmon	0	2016-04-11 13:46:23.164373+00
529	49	26	Lipstick (Hot Pink)	1	2016-04-04 23:43:40.696028+00
1029	74	26	White	0	2016-04-11 13:46:23.175083+00
541	49	33	Bonanza Yellow	0	2016-04-04 23:44:15.892816+00
543	49	33	Bonanza Mixed	1	2016-04-04 23:45:30.317535+00
495	49	61	Mint	1	2016-04-04 23:50:43.462468+00
487	49	60	Big Boy	1	2016-04-04 23:51:21.654894+00
1051	74	34	Yellow	0	2016-04-11 13:48:01.418186+00
555	49	19	\N	1	2016-04-04 23:53:49.622736+00
557	49	23	\N	1	2016-04-04 23:53:52.809979+00
1077	74	41	Dwarf Mixed	0	2016-04-11 13:49:22.765778+00
1090	74	56	Purple	0	2016-04-11 13:52:22.43213+00
1094	74	54	White	0	2016-04-11 13:52:53.362972+00
1098	74	54	Lavender	0	2016-04-11 13:52:53.424161+00
603	52	48	\N	5	2016-04-05 15:21:34.539885+00
613	52	5	or Gerbera Daisy mix	0	2016-04-05 15:22:44.097402+00
592	52	3	\N	3	2016-04-05 15:23:40.62765+00
611	52	5	Geranium w spike (white, magenta, pink, or coral)	1	2016-04-05 15:24:21.49439+00
614	53	60	Beefsteak	0	2016-04-05 17:57:18.389286+00
616	53	60	Big Boy	1	2016-04-05 17:57:37.998637+00
619	53	26	Lipstick (Hot Pink)	0	2016-04-05 17:58:15.524177+00
621	53	26	Pink	0	2016-04-05 17:58:15.593478+00
623	53	26	Violet (dk. violet/purple)	0	2016-04-05 17:58:15.606132+00
625	53	26	Salmon	0	2016-04-05 17:58:15.673479+00
627	53	38	\N	1	2016-04-05 17:59:01.804839+00
628	53	61	Cilantro	1	2016-04-05 18:00:01.633262+00
630	53	61	Basil (Sweet Italian)	1	2016-04-05 18:00:01.646765+00
632	53	61	Oregano (Italian)	0	2016-04-05 18:00:01.659052+00
634	53	61	Mint	0	2016-04-05 18:00:01.70347+00
1101	74	52	Deep Red	0	2016-04-11 13:53:45.600501+00
643	54	59	Yellow Bell	0	2016-04-06 12:20:45.054142+00
667	55	30	\N	1	2016-04-06 13:19:40.773116+00
698	56	33	Bonanza Yellow	0	2016-04-06 17:38:43.012951+00
700	56	33	Bonanza Mixed	0	2016-04-06 17:38:43.057288+00
703	58	1	\N	2	2016-04-06 17:45:52.13015+00
781	64	59	Jalapeno	0	2016-04-08 02:59:02.706653+00
779	64	59	Green Bell	1	2016-04-08 02:59:09.113016+00
747	60	13	purple	4	2016-04-06 20:13:27.117313+00
748	60	42	White/Eye	0	2016-04-06 20:16:50.241738+00
750	60	42	Red	0	2016-04-06 20:16:50.251493+00
784	64	60	Big Boy	0	2016-04-08 02:59:11.756288+00
782	64	60	Roma	1	2016-04-08 02:59:22.820003+00
794	68	26	Blue Pearl (pastel lt.purple)	0	2016-04-08 17:17:20.522561+00
796	68	26	Lilac (deep purple/pink)	0	2016-04-08 17:17:20.63622+00
798	68	26	Violet (dk. violet/purple)	0	2016-04-08 17:17:20.651336+00
800	68	26	Salmon	0	2016-04-08 17:17:20.673276+00
802	68	26	Mixed	3	2016-04-08 17:17:40.321774+00
940	72	26	Blue Pearl (pastel lt.purple)	0	2016-04-09 02:49:26.49664+00
942	72	26	Lilac (deep purple/pink)	0	2016-04-09 02:49:26.510997+00
948	72	26	Mixed	0	2016-04-09 02:49:26.566566+00
946	72	26	Violet (dk. violet/purple)	1	2016-04-09 02:50:19.683668+00
944	72	26	Red	1	2016-04-09 02:50:21.013049+00
951	72	39	Yellow	0	2016-04-09 02:50:29.829354+00
1116	74	58	Purple Wave (Magenta)	0	2016-04-11 13:55:27.135104+00
949	72	39	Purple	1	2016-04-09 02:53:40.422478+00
953	72	39	White	1	2016-04-09 02:53:46.005901+00
858	69	61	Cilantro	2	2016-04-08 17:35:39.350306+00
860	69	61	Basil (Sweet Italian)	2	2016-04-08 17:35:44.202183+00
862	69	61	Oregano (Italian)	1	2016-04-08 17:35:46.502363+00
864	69	61	Mint	2	2016-04-08 17:35:47.703994+00
865	69	60	Beefsteak	0	2016-04-08 17:35:52.504267+00
867	69	60	Roma	0	2016-04-08 17:35:52.515677+00
870	69	59	Red Bell	0	2016-04-08 17:36:09.103183+00
872	69	59	Yellow Bell	0	2016-04-08 17:36:09.114818+00
967	73	29	\N	1	2016-04-09 16:04:21.030693+00
1215	77	58	Blue Wave (Dark purple)	1	2016-04-12 23:40:26.354921+00
1403	79	58	White Wave	1	2016-04-13 02:16:56.294803+00
968	73	43	Dwarf Mixed	1	2016-04-09 16:22:14.008276+00
1221	77	28	Bronze Leaf Rose/Pink	0	2016-04-12 23:41:45.238557+00
1222	77	28	Bronze Leaf Mixed	0	2016-04-12 23:41:45.253258+00
1224	77	28	Green Leaf Red	0	2016-04-12 23:41:45.261199+00
1226	77	28	Green Leaf White	0	2016-04-12 23:41:45.285831+00
995	73	5	Wave petunia mix - red, white, and dark purple	1	2016-04-09 17:42:01.105731+00
1030	74	26	Mixed	0	2016-04-11 13:46:23.179275+00
1125	75	32	Blue	1	2016-04-11 17:43:03.128555+00
1126	75	41	Dwarf Mixed	1	2016-04-11 17:43:15.697448+00
1228	77	48	\N	4	2016-04-12 23:44:16.902758+00
1050	74	34	Orange	0	2016-04-11 13:48:01.414265+00
1052	74	34	Vanilla (Sweet Cream)	0	2016-04-11 13:48:01.424373+00
1144	75	51	\N	4	2016-04-11 17:46:27.047484+00
1146	75	60	Beefsteak	0	2016-04-11 17:46:35.409712+00
1110	74	60	Big Boy	0	2016-04-11 13:54:44.051864+00
1148	75	60	Roma	1	2016-04-11 17:46:35.426207+00
1150	75	58	Blue Wave (Dark purple)	2	2016-04-11 17:46:38.650846+00
1152	75	58	Red Wave	0	2016-04-11 17:46:38.662582+00
1154	75	58	Purple Wave (Magenta)	1	2016-04-11 17:46:38.698507+00
1156	75	61	Parsley	0	2016-04-11 17:46:45.654744+00
1158	75	61	Dill	0	2016-04-11 17:46:45.666303+00
1160	75	61	Oregano (Italian)	0	2016-04-11 17:46:45.694785+00
1162	75	52	Violet (Hot Pink)	6	2016-04-11 17:47:23.086259+00
1164	75	52	Pink	2	2016-04-11 17:47:23.097869+00
1166	75	57	Mixed	3	2016-04-11 17:47:56.782934+00
1171	75	56	Yellow	0	2016-04-11 17:48:18.137871+00
1230	77	49	\N	1	2016-04-12 23:44:38.726388+00
1169	75	56	Purple	2	2016-04-11 17:48:50.909924+00
1167	75	56	Pink	2	2016-04-11 17:48:55.477121+00
1431	79	34	Yellow	0	2016-04-13 02:18:30.703232+00
1181	76	39	Red	0	2016-04-12 12:50:50.288327+00
1183	76	39	Yellow	0	2016-04-12 12:50:50.297582+00
1185	76	39	White	0	2016-04-12 12:50:50.350058+00
1188	76	26	Blue Pearl (pastel lt.purple)	0	2016-04-12 12:51:07.759177+00
1190	76	26	Lipstick (Hot Pink)	0	2016-04-12 12:51:07.776214+00
1192	76	26	Red	0	2016-04-12 12:51:07.851379+00
1194	76	26	Violet (dk. violet/purple)	0	2016-04-12 12:51:07.882454+00
1196	76	26	Mixed	0	2016-04-12 12:51:07.907765+00
1433	79	34	Orange	1	2016-04-13 02:19:02.403812+00
1205	76	58	Blue Wave (Dark purple)	0	2016-04-12 12:51:40.99851+00
1207	76	58	Pink Wave	0	2016-04-12 12:51:41.01108+00
1209	76	58	Purple Wave (Magenta)	0	2016-04-12 12:51:41.052034+00
1211	77	60	Beefsteak	0	2016-04-12 23:39:54.2037+00
1213	77	60	Big Boy	0	2016-04-12 23:39:54.304041+00
1217	77	58	Pink Wave	0	2016-04-12 23:40:16.488229+00
1219	77	58	Purple Wave (Magenta)	0	2016-04-12 23:40:16.522757+00
1447	79	8	red	2	2016-04-13 02:21:53.68923+00
1475	80	60	Roma	1	2016-04-13 04:51:54.754368+00
1450	79	60	Roma	0	2016-04-13 02:22:42.45796+00
1452	79	60	Big Boy	0	2016-04-13 02:22:42.512962+00
1455	79	61	Parsley	0	2016-04-13 02:22:58.181271+00
1477	80	60	Sweet 100 (cherry tomatoes)	2	2016-04-13 04:51:56.016759+00
1457	79	61	Dill	1	2016-04-13 02:23:23.037753+00
1460	79	61	Oregano (Italian)	0	2016-04-13 02:23:31.700788+00
1449	79	41	Dwarf Mixed	1	2016-04-13 02:41:35.195732+00
1463	80	61	Parsley	0	2016-04-13 04:47:56.668721+00
1467	80	61	Oregano (Italian)	1	2016-04-13 04:48:06.395217+00
1261	77	52	Deep Red	1	2016-04-12 23:52:17.425539+00
1263	77	52	White	1	2016-04-12 23:52:30.428848+00
1465	80	61	Basil (Sweet Italian)	1	2016-04-13 04:48:07.621772+00
1473	80	59	Jalapeno	0	2016-04-13 04:51:50.102647+00
1471	80	59	Yellow Bell	1	2016-04-13 04:51:58.381281+00
1533	81	34	Vanilla (Sweet Cream)	0	2016-04-13 13:29:24.895415+00
1542	81	40	Tall Red	1	2016-04-13 13:32:35.734853+00
1558	81	49	\N	6	2016-04-13 13:34:42.488297+00
1535	81	34	Orange	1	2016-04-13 13:35:31.976448+00
1575	82	35	\N	1	2016-04-13 19:07:01.858897+00
1578	82	26	Lilac (deep purple/pink)	0	2016-04-13 19:09:17.791578+00
1572	78	51	\N	4	2016-04-13 18:03:25.503121+00
1582	82	26	Salmon	0	2016-04-13 19:09:17.814783+00
1584	82	26	White	0	2016-04-13 19:09:17.848344+00
1580	82	26	Lipstick (Hot Pink)	1	2016-04-13 19:09:22.397365+00
702	56	50	\N	4	2016-04-18 13:25:22.073432+00
1590	83	26	Blue Pearl (pastel lt.purple)	0	2016-04-13 20:53:59.623588+00
668	55	32	Blue	3	2016-04-06 13:20:01.821905+00
670	55	36	\N	1	2016-04-06 13:21:10.317107+00
669	55	46	Mixed	1	2016-04-06 13:21:29.389542+00
671	55	40	Red	0	2016-04-06 13:21:40.719325+00
672	55	40	Tall Red	0	2016-04-06 13:21:40.779242+00
673	55	40	Victoria Blue	1	2016-04-06 13:21:49.114434+00
674	55	50	\N	2	2016-04-06 13:22:32.134565+00
675	55	51	\N	4	2016-04-06 13:22:45.834749+00
677	55	52	Deep Red	0	2016-04-06 13:23:01.996776+00
678	55	52	Pink	0	2016-04-06 13:23:02.062657+00
676	55	52	Violet (Hot Pink)	7	2016-04-06 13:23:37.565415+00
679	55	52	White	3	2016-04-06 13:23:41.620405+00
680	55	55	White	6	2016-04-06 13:24:28.175255+00
681	55	57	Mixed	2	2016-04-06 13:24:56.336325+00
683	55	60	Roma	0	2016-04-06 13:25:11.885793+00
684	55	60	Big Boy	0	2016-04-06 13:25:12.022829+00
682	55	60	Beefsteak	1	2016-04-06 13:25:19.337944+00
685	55	60	Sweet 100 (cherry tomatoes)	2	2016-04-06 13:25:22.465142+00
692	55	61	Oregano (Italian)	0	2016-04-06 13:25:30.251878+00
686	55	61	Cilantro	2	2016-04-06 13:25:36.393692+00
688	55	61	Dill	2	2016-04-06 13:25:39.219979+00
691	55	61	Mint	1	2016-04-06 13:25:42.39421+00
687	55	61	Parsley	1	2016-04-06 13:25:45.384803+00
690	55	61	Thyme	1	2016-04-06 13:25:48.614387+00
689	55	61	Basil (Sweet Italian)	3	2016-04-06 13:25:50.404405+00
941	72	26	Lipstick (Hot Pink)	0	2016-04-09 02:49:26.505925+00
943	72	26	Pink	0	2016-04-09 02:49:26.516963+00
945	72	26	Salmon	0	2016-04-09 02:49:26.527555+00
786	52	4	\N	2	2016-04-08 13:13:18.071583+00
795	68	26	Lipstick (Hot Pink)	0	2016-04-08 17:17:20.587033+00
797	68	26	Pink	0	2016-04-08 17:17:20.648328+00
799	68	26	Red	0	2016-04-08 17:17:20.670122+00
801	68	26	White	0	2016-04-08 17:17:20.695609+00
947	72	26	White	1	2016-04-09 02:50:17.878389+00
954	72	39	Mixed	0	2016-04-09 02:50:29.926274+00
952	72	39	Pink	1	2016-04-09 02:53:03.205906+00
1113	74	58	Red Wave	0	2016-04-11 13:55:27.099442+00
950	72	39	Red	0	2016-04-09 02:53:43.253158+00
1115	74	58	White Wave	0	2016-04-11 13:55:27.110718+00
1059	74	37	\N	0	2016-04-11 13:57:29.058761+00
1076	74	46	Mixed	0	2016-04-11 13:57:38.315696+00
1399	79	58	Blue Wave (Dark purple)	1	2016-04-13 02:16:52.68626+00
994	73	5	Geranium w spike (white, magenta, pink, or coral)	0	2016-04-09 17:19:22.9327+00
996	73	5	or Gerbera Daisy mix	0	2016-04-09 17:19:22.94169+00
749	60	42	Mixed	1	2016-04-06 20:17:23.056163+00
1105	74	59	Yellow Bell	0	2016-04-11 13:59:02.971055+00
1404	79	48	\N	4	2016-04-13 02:17:15.018205+00
1405	79	50	\N	4	2016-04-13 02:17:30.97448+00
1182	76	39	Purple	0	2016-04-12 12:50:50.292079+00
1127	75	41	Tall Mixed	0	2016-04-11 17:43:11.649586+00
1184	76	39	Pink	0	2016-04-12 12:50:50.336882+00
1186	76	39	Mixed	0	2016-04-12 12:50:50.355456+00
1078	74	41	Tall Mixed	0	2016-04-11 13:49:22.766633+00
861	69	61	Dill	2	2016-04-08 17:35:36.219591+00
859	69	61	Parsley	1	2016-04-08 17:35:40.838023+00
863	69	61	Thyme	1	2016-04-08 17:35:45.316956+00
868	69	60	Big Boy	0	2016-04-08 17:35:52.524604+00
866	69	60	Sweet 100 (cherry tomatoes)	2	2016-04-08 17:36:06.709773+00
869	69	59	Green Bell	0	2016-04-08 17:36:09.096705+00
871	69	59	Jalapeno	1	2016-04-08 17:36:13.860175+00
1187	76	29	\N	1	2016-04-12 12:50:59.413616+00
1089	74	56	Red	0	2016-04-11 13:52:22.428985+00
1091	74	56	White	0	2016-04-11 13:52:22.442202+00
1189	76	26	Lilac (deep purple/pink)	0	2016-04-12 12:51:07.771567+00
1097	74	54	Red	0	2016-04-11 13:52:53.381568+00
1191	76	26	Pink	0	2016-04-12 12:51:07.812726+00
891	69	13	\N	1	2016-04-08 17:37:07.013566+00
1193	76	26	Salmon	0	2016-04-12 12:51:07.856446+00
1195	76	26	White	0	2016-04-12 12:51:07.904669+00
1109	74	60	Roma	0	2016-04-11 13:54:44.045457+00
1206	76	58	Red Wave	0	2016-04-12 12:51:41.002237+00
1143	75	48	\N	4	2016-04-11 17:46:24.890159+00
1145	75	50	\N	2	2016-04-11 17:46:28.076408+00
1147	75	60	Big Boy	1	2016-04-11 17:46:35.41397+00
1149	75	60	Sweet 100 (cherry tomatoes)	0	2016-04-11 17:46:35.43122+00
1151	75	58	Pink Wave	1	2016-04-11 17:46:38.655203+00
1153	75	58	White Wave	1	2016-04-11 17:46:38.667278+00
1155	75	61	Cilantro	0	2016-04-11 17:46:45.64263+00
1157	75	61	Thyme	0	2016-04-11 17:46:45.659351+00
1161	75	61	Mint	0	2016-04-11 17:46:45.702547+00
1159	75	61	Basil (Sweet Italian)	3	2016-04-11 17:47:00.566845+00
1163	75	52	White	0	2016-04-11 17:47:23.091436+00
1165	75	52	Deep Red	3	2016-04-11 17:47:23.102539+00
1168	75	56	Red	0	2016-04-11 17:48:18.096413+00
1170	75	56	White	0	2016-04-11 17:48:18.10676+00
1432	79	34	Vanilla (Sweet Cream)	0	2016-04-13 02:18:58.931941+00
1095	74	54	Pink	0	2016-04-11 20:01:18.726671+00
1208	76	58	White Wave	0	2016-04-12 12:51:41.014628+00
1212	77	60	Roma	0	2016-04-12 23:39:54.254174+00
1214	77	60	Sweet 100 (cherry tomatoes)	1	2016-04-12 23:40:03.802051+00
1216	77	58	Red Wave	1	2016-04-12 23:40:31.439544+00
1218	77	58	White Wave	1	2016-04-12 23:40:33.725587+00
1220	77	28	Bronze Leaf Red	0	2016-04-12 23:41:45.237605+00
1223	77	28	Bronze Leaf White	0	2016-04-12 23:41:45.256329+00
1227	77	28	Green Leaf Mixed	0	2016-04-12 23:41:45.587044+00
1225	77	28	Green Leaf Rose/Pink	1	2016-04-12 23:42:23.226163+00
1229	77	51	\N	1	2016-04-12 23:44:34.45232+00
1448	79	41	Tall Mixed	0	2016-04-13 02:22:14.797928+00
1453	79	60	Sweet 100 (cherry tomatoes)	0	2016-04-13 02:22:42.520737+00
1451	79	60	Beefsteak	1	2016-04-13 02:32:21.390195+00
1454	79	61	Cilantro	0	2016-04-13 02:22:58.1765+00
1260	77	52	Violet (Hot Pink)	1	2016-04-12 23:52:06.972728+00
1262	77	52	Pink	1	2016-04-12 23:52:28.05563+00
1458	79	61	Thyme	0	2016-04-13 02:22:58.24101+00
1456	79	61	Basil (Sweet Italian)	1	2016-04-13 02:23:34.803602+00
1459	79	61	Mint	1	2016-04-13 02:26:57.121765+00
1641	84	61	Basil (Sweet Italian)	1	2016-04-13 21:31:32.01189+00
1461	79	57	Mixed	0	2016-04-13 02:42:05.284152+00
1490	81	33	Bonanza Mixed	0	2016-04-13 13:21:37.380221+00
1492	81	33	Bonanza Yellow	1	2016-04-13 13:21:46.882691+00
1710	88	26	Mixed	1	2016-04-14 00:44:45.679264+00
1364	78	30	\N	0	2016-04-13 00:01:58.922737+00
1493	81	39	Purple	0	2016-04-13 13:23:22.536117+00
1495	81	39	Pink	0	2016-04-13 13:23:22.723273+00
1497	81	39	White	0	2016-04-13 13:23:22.736006+00
1639	84	61	Mint	1	2016-04-13 21:32:38.406643+00
1501	81	52	Violet (Hot Pink)	0	2016-04-13 13:25:40.753415+00
1503	81	52	White	8	2016-04-13 13:26:16.435379+00
1505	81	59	Red Bell	0	2016-04-13 13:26:31.387075+00
1507	81	59	Yellow Bell	1	2016-04-13 13:26:39.689461+00
1510	81	60	Roma	0	2016-04-13 13:26:45.797216+00
1512	81	60	Beefsteak	2	2016-04-13 13:26:52.566937+00
1513	81	61	Cilantro	1	2016-04-13 13:27:19.681799+00
1515	81	61	Parsley	2	2016-04-13 13:27:22.468111+00
1519	81	61	Thyme	2	2016-04-13 13:27:30.867957+00
1517	81	61	Mint	1	2016-04-13 13:27:39.712816+00
1647	84	4	\N	1	2016-04-13 21:33:22.575819+00
1541	81	40	Red	0	2016-04-13 13:32:24.923956+00
1543	81	40	Victoria Blue	0	2016-04-13 13:32:25.015427+00
1556	81	48	\N	6	2016-04-13 13:34:11.691981+00
1557	81	51	\N	12	2016-04-13 13:34:24.222148+00
1534	81	34	Yellow	1	2016-04-13 13:35:34.044481+00
1566	78	21	\N	2	2016-04-13 17:55:42.331302+00
1573	78	48	\N	4	2016-04-13 18:02:57.49527+00
1576	82	37	\N	1	2016-04-13 19:07:11.691968+00
1577	82	26	Blue Pearl (pastel lt.purple)	0	2016-04-13 19:09:17.784507+00
1579	82	26	Pink	0	2016-04-13 19:09:17.797913+00
1581	82	26	Red	0	2016-04-13 19:09:17.810246+00
1583	82	26	Violet (dk. violet/purple)	0	2016-04-13 19:09:17.840984+00
1585	82	26	Mixed	0	2016-04-13 19:09:17.852922+00
1592	83	26	Lipstick (Hot Pink)	0	2016-04-13 20:53:59.776132+00
1594	83	26	Red	0	2016-04-13 20:53:59.939074+00
1596	83	26	Violet (dk. violet/purple)	0	2016-04-13 20:53:59.97559+00
1598	83	26	Mixed	1	2016-04-13 20:54:06.083841+00
1599	83	27	Purple	1	2016-04-13 20:54:17.115499+00
1601	83	32	Blue	1	2016-04-13 20:54:32.054992+00
1602	83	34	Orange	0	2016-04-13 20:54:35.324228+00
1604	83	34	Vanilla (Sweet Cream)	1	2016-04-13 20:54:40.65718+00
1605	83	35	\N	1	2016-04-13 20:54:46.810736+00
1612	83	56	Pink	0	2016-04-13 20:56:13.833964+00
1610	83	56	Purple	2	2016-04-13 20:56:21.390935+00
1614	83	58	Red Wave	0	2016-04-13 20:56:58.225769+00
1616	83	58	Pink Wave	0	2016-04-13 20:56:58.23565+00
1618	83	58	Purple Wave (Magenta)	0	2016-04-13 20:56:58.298874+00
1620	84	26	Violet (dk. violet/purple)	0	2016-04-13 21:29:18.024188+00
1622	84	26	Salmon	0	2016-04-13 21:29:18.10484+00
1624	84	26	Lilac (deep purple/pink)	0	2016-04-13 21:29:18.117341+00
1626	84	26	Pink	0	2016-04-13 21:29:18.126479+00
1628	84	30	\N	1	2016-04-13 21:29:59.608309+00
1630	84	59	Green Bell	2	2016-04-13 21:30:46.522286+00
1632	84	59	Jalapeno	3	2016-04-13 21:30:54.284176+00
1635	84	60	Big Boy	0	2016-04-13 21:30:58.137691+00
1637	84	60	Sweet 100 (cherry tomatoes)	2	2016-04-13 21:31:05.972327+00
1643	84	61	Parsley	1	2016-04-13 21:31:26.967342+00
1715	88	39	Red	0	2016-04-14 00:44:53.31178+00
1717	88	39	Yellow	0	2016-04-14 00:44:53.327592+00
1719	88	39	Mixed	1	2016-04-14 00:44:59.070089+00
1678	85	60	Roma	0	2016-04-14 00:03:07.786382+00
1680	85	60	Sweet 100 (cherry tomatoes)	2	2016-04-14 00:03:21.601843+00
1681	86	59	Green Bell	0	2016-04-14 00:10:54.239101+00
1683	86	59	Red Bell	1	2016-04-14 00:11:04.364544+00
1688	86	60	Sweet 100 (cherry tomatoes)	0	2016-04-14 00:11:09.495717+00
1686	86	60	Roma	1	2016-04-14 00:11:17.989599+00
1689	86	61	Cilantro	0	2016-04-14 00:11:20.983748+00
1693	86	61	Oregano (Italian)	0	2016-04-14 00:11:21.049175+00
1695	86	61	Mint	0	2016-04-14 00:11:21.076129+00
1691	86	61	Basil (Sweet Italian)	3	2016-04-14 00:11:45.262042+00
1699	87	6	or Begonia (big)--red	0	2016-04-14 00:42:15.888878+00
1697	87	6	New Guinea Impatiens (lavender or magenta)	2	2016-04-14 00:42:31.752864+00
1700	87	49	\N	2	2016-04-14 00:42:50.610742+00
1701	87	50	\N	2	2016-04-14 00:42:57.825352+00
1702	88	26	Blue Pearl (pastel lt.purple)	0	2016-04-14 00:44:39.241298+00
1704	88	26	Lipstick (Hot Pink)	0	2016-04-14 00:44:39.346701+00
1706	88	26	Red	0	2016-04-14 00:44:39.435394+00
1708	88	26	Violet (dk. violet/purple)	0	2016-04-14 00:44:39.451455+00
1721	88	47	Silver	1	2016-04-14 00:45:22.417405+00
1723	88	52	Deep Red	0	2016-04-14 00:45:42.124024+00
1725	88	52	White	0	2016-04-14 00:45:42.135708+00
1730	88	59	Green Bell	0	2016-04-14 00:46:06.208279+00
1732	88	59	Red Bell	0	2016-04-14 00:46:06.227131+00
1735	88	60	Sweet 100 (cherry tomatoes)	0	2016-04-14 00:46:15.123438+00
1737	88	60	Roma	0	2016-04-14 00:46:15.134512+00
1743	89	26	Lilac (deep purple/pink)	0	2016-04-14 00:51:42.647944+00
1745	89	26	Pink	0	2016-04-14 00:51:42.740177+00
1747	89	26	Salmon	0	2016-04-14 00:51:42.765347+00
1749	89	26	White	0	2016-04-14 00:51:42.776548+00
1751	89	27	Purple	0	2016-04-14 00:51:58.788537+00
1755	89	42	Red	0	2016-04-14 00:52:16.852816+00
1759	89	60	Roma	0	2016-04-14 00:52:45.013932+00
1761	89	60	Sweet 100 (cherry tomatoes)	1	2016-04-14 00:52:52.514737+00
1762	89	61	Cilantro	0	2016-04-14 00:52:59.311886+00
1768	89	61	Mint	0	2016-04-14 00:52:59.419973+00
1764	89	61	Basil (Sweet Italian)	1	2016-04-14 00:53:12.390707+00
1766	89	61	Thyme	1	2016-04-14 00:53:20.610479+00
1771	90	59	Yellow Bell	0	2016-04-14 00:55:50.588982+00
1773	90	59	Jalapeno	0	2016-04-14 00:55:50.697282+00
1775	90	60	Roma	0	2016-04-14 00:56:01.334929+00
1777	90	60	Big Boy	0	2016-04-14 00:56:01.370861+00
1781	91	27	White	2	2016-04-14 00:58:54.066336+00
1778	91	2	\N	1	2016-04-14 00:58:16.878687+00
1780	91	27	Purple	0	2016-04-14 00:58:49.423881+00
1786	91	32	Blue	2	2016-04-14 00:59:06.595014+00
1788	91	41	Tall Mixed	0	2016-04-14 00:59:15.895743+00
1787	91	41	Dwarf Mixed	1	2016-04-14 00:59:25.577956+00
1789	91	43	Dwarf Mixed	1	2016-04-14 00:59:36.877432+00
1790	91	59	Green Bell	0	2016-04-14 00:59:43.711973+00
1792	91	59	Red Bell	0	2016-04-14 00:59:43.730094+00
1793	91	59	Jalapeno	0	2016-04-14 00:59:43.740675+00
1791	91	59	Yellow Bell	1	2016-04-14 00:59:52.055148+00
1794	91	60	Beefsteak	0	2016-04-14 00:59:54.86132+00
1795	91	60	Roma	0	2016-04-14 00:59:54.869432+00
1797	91	60	Sweet 100 (cherry tomatoes)	1	2016-04-14 01:00:02.630632+00
1796	91	60	Big Boy	1	2016-04-14 01:00:06.312748+00
1464	80	61	Mint	0	2016-04-13 04:47:56.724941+00
1466	80	61	Thyme	0	2016-04-13 04:47:56.777037+00
1468	80	61	Dill	0	2016-04-13 04:47:56.788879+00
1462	80	61	Cilantro	1	2016-04-13 04:48:14.047737+00
1474	80	60	Beefsteak	0	2016-04-13 04:51:50.653689+00
1476	80	60	Big Boy	0	2016-04-13 04:51:50.664039+00
1470	80	59	Green Bell	1	2016-04-13 04:51:57.67018+00
1472	80	59	Red Bell	1	2016-04-13 04:51:59.071913+00
1629	84	48	\N	4	2016-04-13 21:30:20.755822+00
1489	81	33	Bonanza Bee (Yellow-orange)	0	2016-04-13 13:21:37.256241+00
1491	81	33	Bonanza Orange	1	2016-04-13 13:21:49.705591+00
1633	84	59	Yellow Bell	0	2016-04-13 21:30:38.945427+00
1496	81	39	Red	0	2016-04-13 13:23:22.729946+00
1498	81	39	Mixed	0	2016-04-13 13:23:22.740278+00
1377	78	26	Lilac (deep purple/pink)	0	2016-04-13 01:47:18.409259+00
1378	78	26	Blue Pearl (pastel lt.purple)	0	2016-04-13 01:47:18.414831+00
1380	78	26	Red	0	2016-04-13 01:47:18.430815+00
1381	78	26	Pink	0	2016-04-13 01:47:18.434334+00
1382	78	26	Salmon	0	2016-04-13 01:47:18.441903+00
1383	78	26	Violet (dk. violet/purple)	0	2016-04-13 01:47:18.463117+00
1384	78	26	White	0	2016-04-13 01:47:18.47768+00
1385	78	26	Mixed	0	2016-04-13 01:47:18.482786+00
1386	78	3	\N	2	2016-04-13 01:48:39.665522+00
1387	78	2	\N	1	2016-04-13 01:48:43.748479+00
1388	78	4	\N	2	2016-04-13 01:48:45.970201+00
1494	81	39	Yellow	1	2016-04-13 13:24:31.391744+00
1502	81	52	Deep Red	0	2016-04-13 13:25:40.755461+00
1394	78	40	Red	0	2016-04-13 01:49:29.298299+00
1395	78	40	Tall Red	0	2016-04-13 01:49:29.304939+00
1396	78	40	Victoria Blue	1	2016-04-13 01:49:29.315417+00
1397	78	43	Dwarf Mixed	1	2016-04-13 01:49:32.343029+00
1504	81	52	Pink	0	2016-04-13 13:25:40.773287+00
1508	81	59	Green Bell	1	2016-04-13 13:26:37.384647+00
1506	81	59	Jalapeno	1	2016-04-13 13:26:41.630185+00
1511	81	60	Big Boy	1	2016-04-13 13:26:57.573609+00
1509	81	60	Sweet 100 (cherry tomatoes)	1	2016-04-13 13:27:01.57926+00
1516	81	61	Basil (Sweet Italian)	2	2016-04-13 13:27:25.433169+00
1514	81	61	Dill	1	2016-04-13 13:27:27.636107+00
1518	81	61	Oregano (Italian)	1	2016-04-13 13:27:37.154068+00
1631	84	59	Red Bell	2	2016-04-13 21:30:50.154112+00
1634	84	60	Beefsteak	0	2016-04-13 21:30:58.035003+00
1636	84	60	Roma	1	2016-04-13 21:31:10.650708+00
1393	78	38	\N	0	2016-04-13 17:56:39.031042+00
1638	84	61	Cilantro	1	2016-04-13 21:31:24.040221+00
1640	84	61	Dill	1	2016-04-13 21:31:35.049147+00
1379	78	26	Lipstick (Hot Pink)	1	2016-04-13 18:09:47.893764+00
1589	83	17	\N	1	2016-04-13 20:53:35.015964+00
1591	83	26	Lilac (deep purple/pink)	0	2016-04-13 20:53:59.684387+00
1593	83	26	Pink	0	2016-04-13 20:53:59.818913+00
1595	83	26	Salmon	0	2016-04-13 20:53:59.948148+00
1597	83	26	White	0	2016-04-13 20:53:59.985965+00
1600	83	27	White	1	2016-04-13 20:54:20.352057+00
1603	83	34	Yellow	0	2016-04-13 20:54:35.328443+00
1606	83	44	Mixed	1	2016-04-13 20:55:23.401989+00
1607	83	48	\N	2	2016-04-13 20:55:40.849289+00
1608	83	51	\N	2	2016-04-13 20:55:49.694714+00
1609	83	56	Red	0	2016-04-13 20:56:13.652287+00
1611	83	56	White	0	2016-04-13 20:56:13.789861+00
1613	83	56	Yellow	2	2016-04-13 20:56:28.882519+00
1615	83	58	Blue Wave (Dark purple)	1	2016-04-13 20:57:07.413597+00
1617	83	58	White Wave	1	2016-04-13 20:57:11.41135+00
1619	84	26	Blue Pearl (pastel lt.purple)	0	2016-04-13 21:29:17.955806+00
1621	84	26	Red	0	2016-04-13 21:29:18.095516+00
1625	84	26	White	0	2016-04-13 21:29:18.121764+00
1627	84	26	Mixed	0	2016-04-13 21:29:18.161232+00
1623	84	26	Lipstick (Hot Pink)	2	2016-04-13 21:29:24.482246+00
1696	87	2	\N	2	2016-04-14 00:42:07.527547+00
1642	84	61	Oregano (Italian)	1	2016-04-13 21:32:28.957981+00
1644	84	61	Thyme	1	2016-04-13 21:32:32.20975+00
1698	87	6	Go-Go Begonia-red w/creeping jenny or yellow w/silver dichondra	0	2016-04-14 00:42:15.838219+00
1703	88	26	Lilac (deep purple/pink)	0	2016-04-14 00:44:39.296927+00
1705	88	26	Pink	0	2016-04-14 00:44:39.405424+00
1677	85	60	Beefsteak	0	2016-04-14 00:03:07.765709+00
1679	85	60	Big Boy	1	2016-04-14 00:03:29.812936+00
1682	86	59	Yellow Bell	0	2016-04-14 00:10:54.293408+00
1684	86	59	Jalapeno	1	2016-04-14 00:11:08.686748+00
1685	86	60	Beefsteak	0	2016-04-14 00:11:09.405151+00
1687	86	60	Big Boy	0	2016-04-14 00:11:09.486666+00
1690	86	61	Parsley	1	2016-04-14 00:11:41.149953+00
1692	86	61	Dill	1	2016-04-14 00:11:55.718018+00
1694	86	61	Thyme	1	2016-04-14 00:11:59.521447+00
1707	88	26	Salmon	0	2016-04-14 00:44:39.445157+00
1709	88	26	White	0	2016-04-14 00:44:39.454924+00
1714	88	39	Purple	0	2016-04-14 00:44:53.303276+00
1716	88	39	Pink	0	2016-04-14 00:44:53.319739+00
1718	88	39	White	0	2016-04-14 00:44:53.335303+00
1722	88	52	Violet (Hot Pink)	1	2016-04-14 00:45:51.838524+00
1724	88	52	Pink	1	2016-04-14 00:45:58.754824+00
1731	88	59	Yellow Bell	0	2016-04-14 00:46:06.216844+00
1733	88	59	Jalapeno	1	2016-04-14 00:46:12.81314+00
1734	88	60	Beefsteak	0	2016-04-14 00:46:15.116056+00
1736	88	60	Big Boy	1	2016-04-14 00:46:21.072395+00
1738	89	9	pink	1	2016-04-14 00:50:54.38841+00
1739	89	11	pink	1	2016-04-14 00:51:07.158572+00
1740	89	13	pink	1	2016-04-14 00:51:17.510654+00
1741	89	17	\N	2	2016-04-14 00:51:33.645043+00
1742	89	26	Blue Pearl (pastel lt.purple)	0	2016-04-14 00:51:42.596001+00
1746	89	26	Red	0	2016-04-14 00:51:42.757707+00
1748	89	26	Violet (dk. violet/purple)	0	2016-04-14 00:51:42.774202+00
1750	89	26	Mixed	0	2016-04-14 00:51:42.78329+00
1744	89	26	Lipstick (Hot Pink)	2	2016-04-14 00:51:53.683685+00
1752	89	27	White	1	2016-04-14 00:52:05.327812+00
1756	89	42	White/Eye	0	2016-04-14 00:52:16.85878+00
1754	89	42	Mixed	1	2016-04-14 00:52:23.622521+00
1757	89	43	Dwarf Mixed	1	2016-04-14 00:52:32.933141+00
1758	89	60	Beefsteak	0	2016-04-14 00:52:44.99817+00
1760	89	60	Big Boy	0	2016-04-14 00:52:45.016919+00
1765	89	61	Dill	0	2016-04-14 00:52:59.37119+00
1767	89	61	Oregano (Italian)	0	2016-04-14 00:52:59.383095+00
1763	89	61	Parsley	2	2016-04-14 00:53:08.02609+00
1769	90	25	\N	2	2016-04-14 00:55:34.444257+00
1770	90	59	Green Bell	0	2016-04-14 00:55:50.534548+00
1772	90	59	Red Bell	1	2016-04-14 00:55:59.015484+00
1774	90	60	Beefsteak	0	2016-04-14 00:56:01.283092+00
1776	90	60	Sweet 100 (cherry tomatoes)	3	2016-04-14 00:56:08.425921+00
1779	91	19	\N	2	2016-04-14 00:58:20.124105+00
1802	91	61	Thyme	0	2016-04-14 01:00:13.045854+00
1798	91	61	Cilantro	1	2016-04-14 01:00:24.617824+00
1800	91	61	Basil (Sweet Italian)	1	2016-04-14 01:00:31.397678+00
1804	91	61	Mint	1	2016-04-14 01:00:41.356376+00
1799	91	61	Parsley	0	2016-04-14 01:00:12.797964+00
1801	91	61	Dill	0	2016-04-14 01:00:12.816499+00
1803	91	61	Oregano (Italian)	1	2016-04-14 01:00:37.311221+00
1805	92	1	\N	2	2016-04-14 01:03:48.56832+00
1806	92	24	\N	2	2016-04-14 01:04:03.211625+00
1807	92	26	Blue Pearl (pastel lt.purple)	0	2016-04-14 01:04:13.189589+00
1808	92	26	Lilac (deep purple/pink)	0	2016-04-14 01:04:13.243965+00
1809	92	26	Lipstick (Hot Pink)	0	2016-04-14 01:04:13.294738+00
1810	92	26	Pink	0	2016-04-14 01:04:13.353398+00
1811	92	26	Salmon	0	2016-04-14 01:04:13.392176+00
1812	92	26	Red	0	2016-04-14 01:04:13.395636+00
1814	92	26	White	0	2016-04-14 01:04:13.413009+00
1815	92	26	Mixed	0	2016-04-14 01:04:13.417606+00
1813	92	26	Violet (dk. violet/purple)	1	2016-04-14 01:04:23.871514+00
1816	92	51	\N	4	2016-04-14 01:04:41.918731+00
1817	92	52	Violet (Hot Pink)	0	2016-04-14 01:04:49.729325+00
1819	92	52	Pink	0	2016-04-14 01:04:49.746198+00
1820	92	52	White	0	2016-04-14 01:04:49.751853+00
1818	92	52	Deep Red	8	2016-04-14 01:04:56.419758+00
1821	93	18	\N	3	2016-04-14 01:07:27.810319+00
1822	93	19	\N	6	2016-04-14 01:07:44.18133+00
1823	93	21	\N	3	2016-04-14 01:08:08.450351+00
1824	93	22	\N	6	2016-04-14 01:08:25.234832+00
1825	93	26	Blue Pearl (pastel lt.purple)	0	2016-04-14 01:08:50.124921+00
1826	93	26	Lilac (deep purple/pink)	0	2016-04-14 01:08:50.425607+00
1827	93	26	Lipstick (Hot Pink)	0	2016-04-14 01:08:50.486029+00
1828	93	26	Pink	0	2016-04-14 01:08:50.54436+00
1829	93	26	Red	0	2016-04-14 01:08:50.591647+00
1830	93	26	Salmon	0	2016-04-14 01:08:50.649138+00
1831	93	26	Violet (dk. violet/purple)	0	2016-04-14 01:08:50.963024+00
1832	93	26	White	0	2016-04-14 01:08:51.015183+00
1833	93	26	Mixed	4	2016-04-14 01:09:07.205858+00
1834	93	28	Bronze Leaf Red	0	2016-04-14 01:09:18.015665+00
1835	93	28	Bronze Leaf Rose/Pink	0	2016-04-14 01:09:18.318518+00
1836	93	28	Bronze Leaf White	0	2016-04-14 01:09:18.568139+00
1837	93	28	Bronze Leaf Mixed	0	2016-04-14 01:09:18.572744+00
1838	93	28	Green Leaf Red	0	2016-04-14 01:09:18.578914+00
1839	93	28	Green Leaf White	0	2016-04-14 01:09:18.58534+00
1840	93	28	Green Leaf Rose/Pink	0	2016-04-14 01:09:18.590013+00
1880	95	6	New Guinea Impatiens (lavender or magenta)	2	2016-04-14 01:16:46.728711+00
1841	93	28	Green Leaf Mixed	2	2016-04-14 01:09:33.153979+00
1843	93	41	Tall Mixed	0	2016-04-14 01:10:24.796629+00
1842	93	41	Dwarf Mixed	1	2016-04-14 01:10:46.002675+00
1844	94	1	\N	2	2016-04-14 01:10:59.358507+00
1846	94	23	\N	2	2016-04-14 01:11:25.190458+00
1847	94	26	Blue Pearl (pastel lt.purple)	0	2016-04-14 01:11:37.307724+00
1848	94	26	Lilac (deep purple/pink)	0	2016-04-14 01:11:37.367119+00
1850	94	26	Salmon	0	2016-04-14 01:11:37.471197+00
1851	94	26	Pink	0	2016-04-14 01:11:37.477354+00
1852	94	26	Red	0	2016-04-14 01:11:37.483082+00
1853	94	26	Violet (dk. violet/purple)	0	2016-04-14 01:11:37.49109+00
1854	94	26	White	0	2016-04-14 01:11:37.495455+00
1855	94	26	Mixed	0	2016-04-14 01:11:37.501128+00
1845	93	44	Mixed	1	2016-04-14 01:11:41.761367+00
1849	94	26	Lipstick (Hot Pink)	1	2016-04-14 01:11:43.935602+00
1856	94	60	Beefsteak	0	2016-04-14 01:12:16.871338+00
1858	94	60	Big Boy	0	2016-04-14 01:12:16.892846+00
1857	94	60	Roma	1	2016-04-14 01:12:33.475981+00
1859	94	60	Sweet 100 (cherry tomatoes)	1	2016-04-14 01:12:38.211051+00
1862	93	54	Purple	0	2016-04-14 01:12:44.389968+00
1865	94	61	Cilantro	0	2016-04-14 01:12:51.301392+00
1866	94	61	Parsley	0	2016-04-14 01:12:51.313131+00
1868	94	61	Dill	0	2016-04-14 01:12:51.32859+00
1869	94	61	Thyme	0	2016-04-14 01:12:51.370758+00
1870	94	61	Oregano (Italian)	0	2016-04-14 01:12:51.377565+00
1871	94	61	Mint	0	2016-04-14 01:12:51.383749+00
1867	94	61	Basil (Sweet Italian)	1	2016-04-14 01:12:58.774776+00
1860	93	54	White	6	2016-04-14 01:13:08.849266+00
1864	93	54	Lavender	6	2016-04-14 01:13:22.853743+00
1861	93	54	Pink	6	2016-04-14 01:13:32.222262+00
1863	93	54	Red	6	2016-04-14 01:13:38.959138+00
1873	93	59	Yellow Bell	0	2016-04-14 01:14:12.456522+00
1875	93	59	Jalapeno	0	2016-04-14 01:14:12.603585+00
1872	93	59	Green Bell	1	2016-04-14 01:14:29.88618+00
1874	93	59	Red Bell	1	2016-04-14 01:14:33.890352+00
1876	93	60	Beefsteak	0	2016-04-14 01:14:43.489437+00
1878	93	60	Big Boy	1	2016-04-14 01:15:09.981912+00
1877	93	60	Roma	1	2016-04-14 01:15:14.825524+00
1879	93	60	Sweet 100 (cherry tomatoes)	1	2016-04-14 01:15:20.409511+00
1881	95	6	Go-Go Begonia-red w/creeping jenny or yellow w/silver dichondra	0	2016-04-14 01:16:36.602947+00
1882	95	6	or Begonia (big)--red	0	2016-04-14 01:16:36.607542+00
1883	95	23	\N	1	2016-04-14 01:17:04.058515+00
1885	95	59	Yellow Bell	0	2016-04-14 01:17:18.299829+00
1886	95	59	Red Bell	0	2016-04-14 01:17:18.305063+00
1887	95	59	Jalapeno	0	2016-04-14 01:17:18.343266+00
1884	95	59	Green Bell	1	2016-04-14 01:17:23.970422+00
1889	95	60	Roma	0	2016-04-14 01:17:26.205935+00
1890	95	60	Big Boy	0	2016-04-14 01:17:26.210549+00
1888	95	60	Beefsteak	1	2016-04-14 01:17:32.264919+00
1891	95	60	Sweet 100 (cherry tomatoes)	1	2016-04-14 01:17:37.447422+00
1893	96	60	Beefsteak	0	2016-04-14 01:19:50.291847+00
1894	96	60	Roma	0	2016-04-14 01:19:50.377058+00
1895	96	60	Big Boy	0	2016-04-14 01:19:50.431835+00
1892	96	21	\N	0	2016-04-14 01:23:44.939914+00
1919	97	52	Violet (Hot Pink)	2	2016-04-14 01:23:51.640333+00
1904	97	2	\N	1	2016-04-14 01:20:58.651889+00
1905	97	6	New Guinea Impatiens (lavender or magenta)	0	2016-04-14 01:21:49.032635+00
1907	97	6	or Begonia (big)--red	0	2016-04-14 01:21:49.134485+00
1906	97	6	Go-Go Begonia-red w/creeping jenny or yellow w/silver dichondra	1	2016-04-14 01:21:58.417967+00
1908	97	22	\N	1	2016-04-14 01:22:16.252089+00
1909	97	24	\N	1	2016-04-14 01:22:21.680723+00
1910	97	37	\N	1	2016-04-14 01:22:37.258963+00
1911	97	39	Purple	0	2016-04-14 01:22:44.306613+00
1912	97	39	Red	0	2016-04-14 01:22:44.372965+00
1913	97	39	Mixed	0	2016-04-14 01:22:44.425766+00
1915	97	39	Pink	0	2016-04-14 01:22:44.492166+00
1916	97	39	White	0	2016-04-14 01:22:44.500113+00
1914	97	39	Yellow	1	2016-04-14 01:22:49.55753+00
1917	97	48	\N	4	2016-04-14 01:23:14.463717+00
1918	97	51	\N	4	2016-04-14 01:23:27.011809+00
1921	97	52	Pink	0	2016-04-14 01:23:41.081792+00
1922	97	52	White	0	2016-04-14 01:23:41.089041+00
1920	97	52	Deep Red	2	2016-04-14 01:23:56.855698+00
1926	97	53	White	0	2016-04-14 01:24:04.771073+00
1924	97	53	Lavender	1	2016-04-14 01:24:16.116834+00
1927	97	59	Green Bell	0	2016-04-14 01:24:24.853512+00
1929	97	59	Red Bell	1	2016-04-14 01:24:41.09266+00
1934	97	60	Sweet 100 (cherry tomatoes)	0	2016-04-14 01:24:49.881044+00
1932	97	60	Roma	1	2016-04-14 01:25:00.695097+00
1938	97	61	Parsley	0	2016-04-14 01:25:09.623594+00
1940	97	61	Dill	0	2016-04-14 01:25:09.636157+00
1942	97	61	Oregano (Italian)	1	2016-04-14 01:25:26.170099+00
1949	98	41	Tall Mixed	0	2016-04-14 01:25:43.356266+00
1954	98	56	Red	0	2016-04-14 01:27:36.00532+00
1960	99	6	Go-Go Begonia-red w/creeping jenny or yellow w/silver dichondra	0	2016-04-14 01:29:18.37383+00
1964	99	26	Blue Pearl (pastel lt.purple)	0	2016-04-14 01:30:31.292253+00
1966	99	26	Lipstick (Hot Pink)	0	2016-04-14 01:30:31.576919+00
1968	99	26	Violet (dk. violet/purple)	0	2016-04-14 01:30:31.640577+00
1970	99	26	Salmon	0	2016-04-14 01:30:31.652717+00
1972	99	26	Mixed	1	2016-04-14 01:30:40.070983+00
1973	99	35	\N	1	2016-04-14 01:30:54.331074+00
1976	99	60	Roma	0	2016-04-14 01:31:31.695336+00
1978	99	60	Sweet 100 (cherry tomatoes)	0	2016-04-14 01:31:31.712925+00
1979	99	61	Cilantro	0	2016-04-14 01:31:45.411277+00
1983	99	61	Thyme	0	2016-04-14 01:31:45.468063+00
1985	99	61	Mint	0	2016-04-14 01:31:45.490812+00
1981	99	61	Basil (Sweet Italian)	2	2016-04-14 01:31:53.584406+00
1989	100	61	Parsley	0	2016-04-14 01:33:34.146379+00
1991	100	61	Dill	0	2016-04-14 01:33:34.292137+00
1993	100	61	Oregano (Italian)	2	2016-04-14 01:33:58.678011+00
1996	101	5	Wave petunia mix - red, white, and dark purple	1	2016-04-14 01:34:10.573513+00
1923	97	53	Pink	0	2016-04-14 01:24:04.739173+00
1925	97	53	Salmon	0	2016-04-14 01:24:04.757254+00
1928	97	59	Yellow Bell	1	2016-04-14 01:24:36.046894+00
1930	97	59	Jalapeno	1	2016-04-14 01:24:45.239553+00
1931	97	60	Beefsteak	0	2016-04-14 01:24:49.86263+00
1933	97	60	Big Boy	0	2016-04-14 01:24:49.875576+00
1937	97	61	Cilantro	0	2016-04-14 01:25:09.612137+00
1941	97	61	Thyme	0	2016-04-14 01:25:09.662251+00
1939	97	61	Basil (Sweet Italian)	1	2016-04-14 01:25:19.416731+00
1943	97	61	Mint	1	2016-04-14 01:25:31.059664+00
2035	103	41	Dwarf Mixed	0	2016-04-14 01:49:11.704463+00
1957	98	56	Pink	0	2016-04-14 01:27:36.17082+00
1959	99	6	New Guinea Impatiens (lavender or magenta)	0	2016-04-14 01:29:18.318687+00
1961	99	6	or Begonia (big)--red	1	2016-04-14 01:29:48.463416+00
1962	99	14	pink	1	2016-04-14 01:30:03.689041+00
1965	99	26	Lilac (deep purple/pink)	0	2016-04-14 01:30:31.525784+00
1967	99	26	Pink	0	2016-04-14 01:30:31.629064+00
1969	99	26	Red	0	2016-04-14 01:30:31.643832+00
1971	99	26	White	0	2016-04-14 01:30:31.656514+00
1974	99	46	Mixed	1	2016-04-14 01:31:16.458738+00
1977	99	60	Big Boy	0	2016-04-14 01:31:31.708048+00
1975	99	60	Beefsteak	2	2016-04-14 01:31:37.735558+00
1980	99	61	Parsley	0	2016-04-14 01:31:45.424063+00
1982	99	61	Dill	0	2016-04-14 01:31:45.435899+00
1984	99	61	Oregano (Italian)	0	2016-04-14 01:31:45.479034+00
1986	100	3	\N	2	2016-04-14 01:32:30.801975+00
1987	100	25	\N	1	2016-04-14 01:32:46.575837+00
1992	100	61	Thyme	0	2016-04-14 01:33:34.318663+00
1994	100	61	Mint	0	2016-04-14 01:33:34.33025+00
1988	100	61	Cilantro	2	2016-04-14 01:33:42.823069+00
1990	100	61	Basil (Sweet Italian)	3	2016-04-14 01:33:49.833365+00
1995	101	5	Geranium w spike (white, magenta, pink, or coral)	0	2016-04-14 01:34:02.539167+00
1997	101	5	or Gerbera Daisy mix	0	2016-04-14 01:34:02.637955+00
1998	101	57	Mixed	4	2016-04-14 01:34:41.248542+00
2036	103	41	Tall Mixed	1	2016-04-14 01:49:18.0002+00
2037	104	26	Blue Pearl (pastel lt.purple)	0	2016-04-14 01:50:36.966649+00
2038	104	26	Lilac (deep purple/pink)	0	2016-04-14 01:50:37.021929+00
2004	101	59	Green Bell	2	2016-04-14 01:35:15.145224+00
2005	101	59	Yellow Bell	2	2016-04-14 01:35:17.653233+00
2006	101	59	Red Bell	2	2016-04-14 01:35:20.231577+00
2007	101	59	Jalapeno	2	2016-04-14 01:35:22.836241+00
2008	101	60	Beefsteak	0	2016-04-14 01:35:27.317711+00
2011	101	60	Sweet 100 (cherry tomatoes)	0	2016-04-14 01:35:27.383028+00
2009	101	60	Roma	1	2016-04-14 01:35:34.305586+00
2010	101	60	Big Boy	1	2016-04-14 01:35:37.120863+00
2040	104	26	Pink	0	2016-04-14 01:50:37.139327+00
2018	102	59	Yellow Bell	0	2016-04-14 01:38:36.1271+00
2020	102	59	Jalapeno	0	2016-04-14 01:38:36.245645+00
2021	102	60	Beefsteak	0	2016-04-14 01:38:38.541607+00
2017	102	59	Green Bell	1	2016-04-14 01:38:47.054185+00
2025	101	58	Blue Wave (Dark purple)	1	2016-04-14 01:38:51.459825+00
2026	101	58	Red Wave	1	2016-04-14 01:38:51.515976+00
2027	101	58	Purple Wave (Magenta)	0	2016-04-14 01:38:51.565567+00
2028	101	58	Pink Wave	0	2016-04-14 01:38:51.580943+00
2019	102	59	Red Bell	1	2016-04-14 01:38:55.963347+00
2022	102	60	Roma	1	2016-04-14 01:39:06.632151+00
2023	102	60	Big Boy	1	2016-04-14 01:39:15.102039+00
2024	102	60	Sweet 100 (cherry tomatoes)	1	2016-04-14 01:39:20.92188+00
2080	105	61	Mint	1	2016-04-14 01:55:57.918299+00
2029	101	58	White Wave	1	2016-04-14 01:44:56.128009+00
2042	104	26	Red	0	2016-04-14 01:50:37.246641+00
2043	104	26	White	0	2016-04-14 01:50:37.26995+00
2044	104	26	Violet (dk. violet/purple)	0	2016-04-14 01:50:37.277739+00
2045	104	26	Salmon	0	2016-04-14 01:50:37.282914+00
2039	104	26	Lipstick (Hot Pink)	1	2016-04-14 01:50:44.481698+00
2041	104	26	Mixed	1	2016-04-14 01:50:51.855171+00
2046	104	28	Bronze Leaf Red	0	2016-04-14 01:50:56.146052+00
2047	104	28	Bronze Leaf Rose/Pink	0	2016-04-14 01:50:56.154522+00
2048	104	28	Bronze Leaf White	0	2016-04-14 01:50:56.160281+00
2049	104	28	Bronze Leaf Mixed	0	2016-04-14 01:50:56.166284+00
2050	104	28	Green Leaf Red	0	2016-04-14 01:50:56.170659+00
2051	104	28	Green Leaf Rose/Pink	0	2016-04-14 01:50:56.210456+00
2052	104	28	Green Leaf White	0	2016-04-14 01:50:56.215071+00
2053	104	28	Green Leaf Mixed	1	2016-04-14 01:51:04.152321+00
2054	104	47	Silver	1	2016-04-14 01:51:18.124402+00
2055	104	48	\N	4	2016-04-14 01:52:04.717199+00
2056	104	50	\N	4	2016-04-14 01:52:12.802866+00
2058	104	58	Red Wave	0	2016-04-14 01:52:34.426713+00
2059	104	58	Pink Wave	0	2016-04-14 01:52:34.480047+00
2060	104	58	White Wave	0	2016-04-14 01:52:34.533455+00
2057	104	58	Blue Wave (Dark purple)	1	2016-04-14 01:52:41.304255+00
2061	104	58	Purple Wave (Magenta)	1	2016-04-14 01:52:48.771338+00
2062	104	61	Cilantro	0	2016-04-14 01:53:00.815032+00
2063	104	61	Parsley	0	2016-04-14 01:53:00.824216+00
2065	104	61	Dill	0	2016-04-14 01:53:00.877886+00
2066	104	61	Thyme	0	2016-04-14 01:53:00.927365+00
2067	104	61	Oregano (Italian)	0	2016-04-14 01:53:00.931976+00
2068	104	61	Mint	0	2016-04-14 01:53:00.953397+00
2064	104	61	Basil (Sweet Italian)	1	2016-04-14 01:53:07.514612+00
2069	105	19	\N	3	2016-04-14 01:53:43.419218+00
2070	105	60	Beefsteak	0	2016-04-14 01:55:12.871372+00
2071	105	60	Roma	2	2016-04-14 01:55:19.649778+00
2072	105	60	Big Boy	0	2016-04-14 01:55:22.188716+00
2073	105	60	Sweet 100 (cherry tomatoes)	0	2016-04-14 01:55:25.948787+00
2074	105	61	Cilantro	0	2016-04-14 01:55:38.813285+00
2075	105	61	Parsley	0	2016-04-14 01:55:38.819964+00
2076	105	61	Basil (Sweet Italian)	0	2016-04-14 01:55:38.826194+00
2077	105	61	Dill	0	2016-04-14 01:55:38.830976+00
2079	105	61	Oregano (Italian)	0	2016-04-14 01:55:38.878927+00
2078	105	61	Thyme	1	2016-04-14 01:56:01.726198+00
2081	106	6	New Guinea Impatiens (lavender or magenta)	0	2016-04-14 01:56:29.420585+00
2082	106	6	Go-Go Begonia-red w/creeping jenny or yellow w/silver dichondra	0	2016-04-14 01:56:29.472054+00
2083	106	6	or Begonia (big)--red	1	2016-04-14 01:57:15.03771+00
2084	106	10	\N	3	2016-04-14 01:57:35.124532+00
2085	106	17	\N	1	2016-04-14 01:57:49.058981+00
2086	106	24	\N	2	2016-04-14 01:58:05.190012+00
2087	106	25	\N	1	2016-04-14 01:58:11.054137+00
2088	106	59	Green Bell	0	2016-04-14 01:58:36.468519+00
2089	106	59	Yellow Bell	0	2016-04-14 01:58:36.526067+00
2090	106	59	Red Bell	0	2016-04-14 01:58:36.57675+00
2091	106	59	Jalapeno	2	2016-04-14 01:58:45.325263+00
2095	106	60	Sweet 100 (cherry tomatoes)	0	2016-04-14 01:58:48.004737+00
2093	106	60	Roma	1	2016-04-14 01:59:01.050895+00
2098	106	61	Parsley	0	2016-04-14 01:59:08.901663+00
2099	106	61	Dill	0	2016-04-14 01:59:08.930028+00
2100	106	61	Thyme	0	2016-04-14 01:59:08.94298+00
2101	106	61	Oregano (Italian)	0	2016-04-14 01:59:08.95884+00
2102	106	61	Mint	0	2016-04-14 01:59:08.971007+00
2096	106	61	Cilantro	2	2016-04-14 01:59:16.419068+00
2097	106	61	Basil (Sweet Italian)	2	2016-04-14 01:59:19.976175+00
2104	107	5	Wave petunia mix - red, white, and dark purple	0	2016-04-14 02:01:15.456837+00
2107	107	6	Go-Go Begonia-red w/creeping jenny or yellow w/silver dichondra	1	2016-04-14 02:01:48.764509+00
2094	106	60	Big Boy	0	2016-04-14 01:58:47.928433+00
2092	106	60	Beefsteak	2	2016-04-14 01:58:55.451425+00
2105	107	5	or Gerbera Daisy mix	0	2016-04-14 02:01:15.507566+00
2103	107	5	Geranium w spike (white, magenta, pink, or coral)	1	2016-04-14 02:01:26.273708+00
2106	107	6	New Guinea Impatiens (lavender or magenta)	0	2016-04-14 02:01:29.496313+00
2108	107	6	or Begonia (big)--red	0	2016-04-14 02:01:29.582077+00
2109	107	23	\N	1	2016-04-14 02:02:07.947331+00
2112	107	41	Tall Mixed	0	2016-04-14 02:02:31.518999+00
2111	107	41	Dwarf Mixed	1	2016-04-14 02:02:37.113993+00
2114	107	59	Yellow Bell	0	2016-04-14 02:02:52.465889+00
2115	107	59	Red Bell	0	2016-04-14 02:02:52.576212+00
2113	107	59	Green Bell	1	2016-04-14 02:02:58.119359+00
2116	107	59	Jalapeno	1	2016-04-14 02:03:02.88238+00
2118	107	60	Roma	0	2016-04-14 02:03:14.821278+00
2120	107	60	Sweet 100 (cherry tomatoes)	0	2016-04-14 02:03:14.872763+00
2117	107	60	Beefsteak	1	2016-04-14 02:03:20.583166+00
2119	107	60	Big Boy	1	2016-04-14 02:03:24.762159+00
2121	108	25	\N	1	2016-04-14 02:03:25.192764+00
2122	107	61	Parsley	0	2016-04-14 02:03:33.508095+00
2123	107	61	Cilantro	0	2016-04-14 02:03:33.512743+00
2125	107	61	Dill	0	2016-04-14 02:03:33.563693+00
2126	107	61	Oregano (Italian)	0	2016-04-14 02:03:33.572464+00
2127	107	61	Thyme	0	2016-04-14 02:03:33.576848+00
2128	107	61	Mint	0	2016-04-14 02:03:33.613923+00
2124	107	61	Basil (Sweet Italian)	1	2016-04-14 02:03:39.726731+00
2130	109	28	Bronze Leaf Rose/Pink	0	2016-04-14 02:06:27.527572+00
2131	109	28	Bronze Leaf White	0	2016-04-14 02:06:27.56596+00
2132	109	28	Bronze Leaf Mixed	0	2016-04-14 02:06:27.57305+00
2133	109	28	Green Leaf Red	0	2016-04-14 02:06:27.589353+00
2134	109	28	Green Leaf White	0	2016-04-14 02:06:27.595407+00
2135	109	28	Green Leaf Rose/Pink	0	2016-04-14 02:06:27.601436+00
2136	109	28	Green Leaf Mixed	0	2016-04-14 02:06:27.606075+00
2129	109	28	Bronze Leaf Red	1	2016-04-14 02:06:36.198046+00
2137	109	32	Blue	1	2016-04-14 02:06:53.056435+00
2138	109	46	Mixed	1	2016-04-14 02:07:30.809176+00
2139	109	47	Silver	1	2016-04-14 02:07:33.987875+00
2141	109	58	Red Wave	0	2016-04-14 02:08:12.508699+00
2142	109	58	Pink Wave	0	2016-04-14 02:08:12.546258+00
2143	109	58	White Wave	0	2016-04-14 02:08:12.549867+00
2144	109	58	Purple Wave (Magenta)	0	2016-04-14 02:08:12.555735+00
2140	109	58	Blue Wave (Dark purple)	1	2016-04-14 02:08:24.208289+00
2146	109	60	Big Boy	0	2016-04-14 02:08:40.341173+00
2148	109	60	Sweet 100 (cherry tomatoes)	0	2016-04-14 02:08:40.35015+00
2145	109	60	Beefsteak	1	2016-04-14 02:08:59.477533+00
2183	112	60	Sweet 100 (cherry tomatoes)	1	2016-04-14 02:33:03.82507+00
2147	109	60	Roma	1	2016-04-14 02:09:06.866226+00
2181	112	60	Roma	0	2016-04-14 02:33:06.648172+00
2180	112	60	Beefsteak	0	2016-04-14 02:33:08.816516+00
2157	102	52	Violet (Hot Pink)	0	2016-04-14 02:20:50.813196+00
2158	102	52	Pink	0	2016-04-14 02:20:50.819915+00
2159	102	52	White	0	2016-04-14 02:20:50.82473+00
2156	102	52	Deep Red	1	2016-04-14 02:20:55.528545+00
2185	113	5	Wave petunia mix - red, white, and dark purple	0	2016-04-14 02:35:36.386071+00
2186	113	5	or Gerbera Daisy mix	0	2016-04-14 02:35:36.425845+00
2184	113	5	Geranium w spike (white, magenta, pink, or coral)	2	2016-04-14 02:35:50.953227+00
2187	113	10	\N	3	2016-04-14 02:36:17.303241+00
2188	113	25	\N	1	2016-04-14 02:36:38.625748+00
2189	113	26	Blue Pearl (pastel lt.purple)	0	2016-04-14 02:37:20.714852+00
2190	113	26	Lilac (deep purple/pink)	0	2016-04-14 02:37:20.980124+00
2169	111	19	\N	2	2016-04-14 02:27:56.580677+00
2170	111	4	\N	4	2016-04-14 02:28:33.377734+00
2172	111	41	Tall Mixed	0	2016-04-14 02:29:21.29173+00
2171	111	41	Dwarf Mixed	1	2016-04-14 02:29:34.64493+00
2173	111	43	Dwarf Mixed	1	2016-04-14 02:29:52.299614+00
2174	112	22	\N	1	2016-04-14 02:31:52.478703+00
2175	112	29	\N	1	2016-04-14 02:32:08.20651+00
2177	112	33	Bonanza Yellow	0	2016-04-14 02:32:17.73702+00
2178	112	33	Bonanza Orange	0	2016-04-14 02:32:17.788062+00
2179	112	33	Bonanza Mixed	0	2016-04-14 02:32:17.835281+00
2176	112	33	Bonanza Bee (Yellow-orange)	1	2016-04-14 02:32:29.982691+00
2182	112	60	Big Boy	0	2016-04-14 02:32:55.499527+00
2191	113	26	Lipstick (Hot Pink)	0	2016-04-14 02:37:21.019924+00
2192	113	26	Pink	0	2016-04-14 02:37:21.030796+00
2193	113	26	Red	0	2016-04-14 02:37:21.037443+00
2194	113	26	Salmon	0	2016-04-14 02:37:21.066094+00
2195	113	26	Violet (dk. violet/purple)	0	2016-04-14 02:37:21.093863+00
2196	113	26	White	0	2016-04-14 02:37:21.096925+00
2197	113	26	Mixed	1	2016-04-14 02:37:29.728676+00
2198	113	30	\N	1	2016-04-14 02:37:34.808783+00
2199	113	60	Beefsteak	0	2016-04-14 02:37:55.835357+00
2200	113	60	Roma	0	2016-04-14 02:37:55.843127+00
2201	113	60	Big Boy	0	2016-04-14 02:37:55.870179+00
2202	113	60	Sweet 100 (cherry tomatoes)	1	2016-04-14 02:37:55.915801+00
2203	113	61	Parsley	0	2016-04-14 02:38:07.177731+00
2204	113	61	Cilantro	0	2016-04-14 02:38:07.185625+00
2205	113	61	Basil (Sweet Italian)	1	2016-04-14 02:38:07.192507+00
2206	113	61	Dill	0	2016-04-14 02:38:07.19711+00
2207	113	61	Oregano (Italian)	0	2016-04-14 02:38:07.450957+00
2209	113	61	Mint	0	2016-04-14 02:38:27.119458+00
2208	113	61	Thyme	0	2016-04-14 02:38:29.690617+00
2210	114	3	\N	2	2016-04-14 02:41:04.726619+00
2211	114	6	New Guinea Impatiens (lavender or magenta)	0	2016-04-14 02:41:10.774638+00
2213	114	6	or Begonia (big)--red	0	2016-04-14 02:41:10.895525+00
2212	114	6	Go-Go Begonia-red w/creeping jenny or yellow w/silver dichondra	1	2016-04-14 02:41:42.409859+00
2214	114	19	\N	1	2016-04-14 02:41:57.611498+00
2215	114	22	\N	2	2016-04-14 02:42:26.16524+00
2216	114	33	Bonanza Bee (Yellow-orange)	0	2016-04-14 02:42:52.798295+00
2217	114	33	Bonanza Yellow	0	2016-04-14 02:42:54.039122+00
2218	114	33	Bonanza Orange	0	2016-04-14 02:42:54.088346+00
2219	114	33	Bonanza Mixed	1	2016-04-14 02:43:03.878317+00
2220	114	39	Purple	0	2016-04-14 02:43:11.012669+00
2221	114	39	Red	0	2016-04-14 02:43:11.019151+00
2222	114	39	Yellow	0	2016-04-14 02:43:11.023186+00
2223	114	39	Pink	0	2016-04-14 02:43:11.071792+00
2224	114	39	White	0	2016-04-14 02:43:11.08388+00
2225	114	39	Mixed	1	2016-04-14 02:43:32.718308+00
2226	114	48	\N	2	2016-04-14 02:44:08.318591+00
2227	114	50	\N	1	2016-04-14 02:44:13.112094+00
2228	114	51	\N	1	2016-04-14 02:44:21.057774+00
2230	114	58	Red Wave	0	2016-04-14 02:45:16.199335+00
2231	114	58	Pink Wave	0	2016-04-14 02:45:16.247481+00
2232	114	58	White Wave	0	2016-04-14 02:45:16.296798+00
2233	114	58	Purple Wave (Magenta)	0	2016-04-14 02:45:16.34882+00
2229	114	58	Blue Wave (Dark purple)	1	2016-04-14 02:45:28.552626+00
2234	114	60	Beefsteak	2	2016-04-14 02:45:55.833267+00
2235	114	60	Roma	0	2016-04-14 02:45:45.402605+00
2237	114	60	Sweet 100 (cherry tomatoes)	1	2016-04-14 02:46:11.389955+00
2239	114	61	Parsley	0	2016-04-14 02:46:54.883191+00
2241	114	61	Dill	1	2016-04-14 02:47:34.571253+00
2243	114	61	Oregano (Italian)	1	2016-04-14 02:48:29.410489+00
2236	114	60	Big Boy	2	2016-04-14 02:46:02.672032+00
2242	114	61	Thyme	0	2016-04-14 02:46:54.911026+00
2244	114	61	Mint	0	2016-04-14 02:46:54.928004+00
2238	114	61	Cilantro	1	2016-04-14 02:47:11.051401+00
2240	114	61	Basil (Sweet Italian)	2	2016-04-14 02:48:19.737723+00
2245	115	19	\N	1	2016-04-14 11:18:18.538979+00
2246	115	59	Green Bell	0	2016-04-14 11:19:06.811966+00
2247	115	59	Yellow Bell	0	2016-04-14 11:19:06.873471+00
2248	115	59	Jalapeno	0	2016-04-14 11:19:06.906455+00
2249	115	59	Red Bell	1	2016-04-14 11:20:00.401105+00
2251	115	60	Roma	0	2016-04-14 11:20:11.203059+00
2252	115	60	Big Boy	0	2016-04-14 11:20:11.251383+00
2316	119	28	Bronze Leaf Red	1	2016-04-17 18:20:41.152895+00
2250	115	60	Beefsteak	1	2016-04-14 11:20:24.782884+00
2253	115	60	Sweet 100 (cherry tomatoes)	2	2016-04-14 11:21:15.861752+00
697	56	33	Bonanza Bee (Yellow-orange)	1	2016-04-17 12:16:30.1025+00
2257	56	61	Dill	0	2016-04-17 12:16:49.417776+00
2258	56	61	Thyme	0	2016-04-17 12:16:49.651259+00
2259	56	61	Oregano (Italian)	0	2016-04-17 12:16:49.658167+00
2260	56	61	Mint	0	2016-04-17 12:16:49.662729+00
2254	56	61	Cilantro	1	2016-04-17 12:17:02.518973+00
2255	56	61	Parsley	1	2016-04-17 12:17:04.868536+00
2256	56	61	Basil (Sweet Italian)	1	2016-04-17 12:17:07.578041+00
2273	56	51	\N	4	2016-04-17 12:19:29.396743+00
2274	56	48	\N	4	2016-04-17 12:19:47.706866+00
2275	56	53	Pink	0	2016-04-17 12:20:00.50045+00
2276	56	53	Lavender	0	2016-04-17 12:20:00.628251+00
2277	56	53	Salmon	0	2016-04-17 12:20:00.656606+00
2279	56	52	Violet (Hot Pink)	0	2016-04-17 12:20:11.535351+00
2281	56	52	Pink	0	2016-04-17 12:20:11.547766+00
2280	56	52	Deep Red	4	2016-04-17 12:20:40.107177+00
2282	56	52	White	4	2016-04-17 12:20:45.478858+00
2278	56	53	White	1	2016-04-17 12:21:09.366734+00
2283	118	18	\N	2	2016-04-17 18:12:44.485354+00
2289	118	27	Purple	0	2016-04-17 18:12:49.149194+00
2290	118	27	White	1	2016-04-17 18:12:55.427012+00
2291	118	40	Red	0	2016-04-17 18:13:10.419761+00
2293	118	40	Victoria Blue	0	2016-04-17 18:13:10.592177+00
2292	118	40	Tall Red	3	2016-04-17 18:13:15.566357+00
2294	118	56	Red	0	2016-04-17 18:13:32.792034+00
2295	118	56	Purple	0	2016-04-17 18:13:32.79556+00
2296	118	56	White	0	2016-04-17 18:13:32.850561+00
2297	118	56	Pink	3	2016-04-17 18:13:41.703235+00
2299	118	61	Cilantro	1	2016-04-17 18:14:00.607672+00
2300	118	61	Parsley	1	2016-04-17 18:14:03.679744+00
2301	118	61	Basil (Sweet Italian)	2	2016-04-17 18:14:07.785069+00
2302	118	61	Dill	1	2016-04-17 18:14:12.337557+00
2303	118	61	Thyme	1	2016-04-17 18:14:15.191283+00
2304	118	61	Oregano (Italian)	1	2016-04-17 18:14:18.076297+00
2305	118	61	Mint	1	2016-04-17 18:14:20.70284+00
2298	118	56	Yellow	2	2016-04-17 18:14:42.437611+00
2306	119	25	\N	2	2016-04-17 18:19:30.616799+00
2307	119	26	Blue Pearl (pastel lt.purple)	0	2016-04-17 18:19:38.981497+00
2308	119	26	Lilac (deep purple/pink)	0	2016-04-17 18:19:39.034129+00
2309	119	26	Pink	0	2016-04-17 18:19:39.073364+00
2310	119	26	Lipstick (Hot Pink)	0	2016-04-17 18:19:39.081472+00
2312	119	26	Violet (dk. violet/purple)	0	2016-04-17 18:19:39.097619+00
2313	119	26	White	0	2016-04-17 18:19:39.100421+00
2314	119	26	Mixed	0	2016-04-17 18:19:39.123694+00
2315	119	26	Salmon	0	2016-04-17 18:19:39.151974+00
2311	119	26	Red	1	2016-04-17 18:19:46.365111+00
2317	119	28	Bronze Leaf Rose/Pink	0	2016-04-17 18:20:31.372457+00
2318	119	28	Bronze Leaf White	0	2016-04-17 18:20:31.384568+00
2319	119	28	Bronze Leaf Mixed	0	2016-04-17 18:20:31.387407+00
2320	119	28	Green Leaf Red	0	2016-04-17 18:20:31.393639+00
2321	119	28	Green Leaf Rose/Pink	0	2016-04-17 18:20:31.398947+00
2322	119	28	Green Leaf White	0	2016-04-17 18:20:31.435881+00
2323	119	28	Green Leaf Mixed	0	2016-04-17 18:20:31.439513+00
2325	119	46	Mixed	1	2016-04-17 18:21:50.018498+00
2326	119	61	Cilantro	0	2016-04-17 18:22:25.562708+00
2327	119	61	Parsley	0	2016-04-17 18:22:25.61725+00
2329	119	61	Dill	0	2016-04-17 18:22:25.659415+00
2330	119	61	Thyme	0	2016-04-17 18:22:25.665591+00
2331	119	61	Mint	0	2016-04-17 18:22:25.671793+00
2332	119	61	Oregano (Italian)	0	2016-04-17 18:22:25.676347+00
2328	119	61	Basil (Sweet Italian)	1	2016-04-17 18:22:34.440547+00
2333	120	48	\N	3	2016-04-17 18:31:08.504677+00
2334	120	49	\N	2	2016-04-17 18:31:15.86789+00
2335	120	51	\N	1	2016-04-17 18:31:24.809691+00
2336	120	52	Violet (Hot Pink)	0	2016-04-17 18:31:34.178322+00
2338	120	52	Pink	2	2016-04-17 18:31:42.835105+00
2337	120	52	Deep Red	5	2016-04-17 18:31:48.274197+00
2339	120	52	White	4	2016-04-17 18:31:52.11217+00
2341	120	54	Pink	0	2016-04-17 18:31:57.772419+00
2342	120	54	Purple	0	2016-04-17 18:31:57.77534+00
2343	120	54	Red	0	2016-04-17 18:31:57.859764+00
2344	120	54	Lavender	0	2016-04-17 18:31:57.861469+00
2340	120	54	White	1	2016-04-17 18:32:08.390774+00
2346	120	61	Parsley	0	2016-04-17 18:32:12.572611+00
2347	120	61	Basil (Sweet Italian)	0	2016-04-17 18:32:12.581392+00
2348	120	61	Dill	0	2016-04-17 18:32:12.623166+00
2349	120	61	Thyme	0	2016-04-17 18:32:12.625141+00
2350	120	61	Oregano (Italian)	0	2016-04-17 18:32:12.640728+00
2351	120	61	Mint	0	2016-04-17 18:32:12.67718+00
2345	120	61	Cilantro	1	2016-04-17 18:32:21.230814+00
2352	121	4	\N	1	2016-04-17 18:36:29.415915+00
2354	121	5	Wave petunia mix - red, white, and dark purple	0	2016-04-17 18:36:35.84513+00
2355	121	5	or Gerbera Daisy mix	0	2016-04-17 18:36:35.880472+00
2353	121	5	Geranium w spike (white, magenta, pink, or coral)	1	2016-04-17 18:36:46.614121+00
2356	121	18	\N	1	2016-04-17 18:37:07.090062+00
2357	121	19	\N	1	2016-04-17 18:37:14.844489+00
2358	121	21	\N	1	2016-04-17 18:37:23.724851+00
2359	121	22	\N	1	2016-04-17 18:37:26.56076+00
2360	122	1	\N	2	2016-04-17 18:40:43.397048+00
2361	122	44	Mixed	1	2016-04-17 18:40:56.223652+00
2362	123	2	\N	1	2016-04-17 18:48:23.489562+00
2363	123	3	\N	1	2016-04-17 18:48:26.446229+00
2364	123	4	\N	1	2016-04-17 18:48:29.93991+00
2366	123	5	Wave petunia mix - red, white, and dark purple	0	2016-04-17 18:48:33.831659+00
2367	123	5	or Gerbera Daisy mix	0	2016-04-17 18:48:33.879788+00
2368	123	11	\N	1	2016-04-17 18:48:45.220466+00
2369	123	14	\N	1	2016-04-17 18:48:51.700767+00
2370	123	16	\N	1	2016-04-17 18:48:58.366005+00
2371	123	29	\N	1	2016-04-17 18:49:13.09039+00
2372	123	48	\N	3	2016-04-17 18:49:38.754366+00
2373	123	50	\N	2	2016-04-17 18:49:51.65487+00
2374	123	51	\N	1	2016-04-17 18:50:00.115004+00
2365	123	5	Geranium w spike (white, magenta, pink, or coral)	1	2016-04-17 18:50:56.310181+00
2375	123	55	White	2	2016-04-17 18:50:27.824479+00
2377	124	2	\N	1	2016-04-17 18:58:24.696569+00
2380	124	26	Blue Pearl (pastel lt.purple)	0	2016-04-17 18:58:49.583661+00
2381	124	26	Lilac (deep purple/pink)	0	2016-04-17 18:58:49.587036+00
2383	124	26	Lipstick (Hot Pink)	0	2016-04-17 18:58:49.646656+00
2385	124	26	Salmon	0	2016-04-17 18:58:49.668724+00
2387	124	26	White	0	2016-04-17 18:58:49.69176+00
2392	124	58	Red Wave	0	2016-04-17 18:59:47.007422+00
2394	124	58	White Wave	2	2016-04-17 19:00:27.720644+00
2397	125	26	Lilac (deep purple/pink)	0	2016-04-17 19:02:37.220858+00
2399	125	26	Pink	0	2016-04-17 19:02:37.40974+00
2401	125	26	Salmon	0	2016-04-17 19:02:37.492945+00
2403	125	26	White	0	2016-04-17 19:02:37.506033+00
2407	125	51	\N	1	2016-04-17 19:03:14.805786+00
2409	125	52	Deep Red	0	2016-04-17 19:03:26.330742+00
2411	125	52	White	0	2016-04-17 19:03:26.343555+00
2415	125	54	Red	0	2016-04-17 19:03:51.499766+00
2413	125	54	Pink	6	2016-04-17 19:03:58.433605+00
2418	125	56	White	0	2016-04-17 19:04:02.474047+00
2420	125	56	Pink	0	2016-04-17 19:04:02.485255+00
2423	125	58	Red Wave	0	2016-04-17 19:05:01.968429+00
2425	125	58	White Wave	1	2016-04-17 19:05:11.177394+00
2428	125	60	Roma	0	2016-04-17 19:05:17.764297+00
2430	125	60	Sweet 100 (cherry tomatoes)	1	2016-04-17 19:05:24.670242+00
2435	125	61	Thyme	0	2016-04-17 19:05:32.55887+00
2437	125	61	Mint	0	2016-04-17 19:05:32.572107+00
2431	125	61	Cilantro	1	2016-04-17 19:05:40.067824+00
2433	125	61	Basil (Sweet Italian)	1	2016-04-17 19:05:49.713394+00
2440	126	50	\N	8	2016-04-17 19:08:26.863146+00
2382	124	26	Pink	0	2016-04-17 18:58:49.641698+00
2384	124	26	Red	0	2016-04-17 18:58:49.65923+00
2386	124	26	Violet (dk. violet/purple)	0	2016-04-17 18:58:49.685005+00
2388	124	26	Mixed	1	2016-04-17 18:58:58.263298+00
2389	124	38	\N	2	2016-04-17 18:59:13.084146+00
2390	124	48	\N	2	2016-04-17 18:59:33.018383+00
2391	124	58	Blue Wave (Dark purple)	0	2016-04-17 18:59:47.002323+00
2393	124	58	Pink Wave	3	2016-04-17 19:00:04.444708+00
2395	124	58	Purple Wave (Magenta)	3	2016-04-17 19:00:14.373041+00
2396	125	26	Blue Pearl (pastel lt.purple)	0	2016-04-17 19:02:37.160633+00
2400	125	26	Red	0	2016-04-17 19:02:37.459245+00
2402	125	26	Violet (dk. violet/purple)	0	2016-04-17 19:02:37.499197+00
2404	125	26	Mixed	0	2016-04-17 19:02:37.510685+00
2398	125	26	Lipstick (Hot Pink)	1	2016-04-17 19:02:45.683731+00
2405	125	32	Blue	1	2016-04-17 19:02:52.405328+00
2406	125	48	\N	1	2016-04-17 19:03:10.724925+00
2408	125	52	Violet (Hot Pink)	3	2016-04-17 19:03:35.086948+00
2410	125	52	Pink	3	2016-04-17 19:03:41.17563+00
2412	125	54	White	0	2016-04-17 19:03:51.47153+00
2414	125	54	Purple	0	2016-04-17 19:03:51.483996+00
2416	125	54	Lavender	0	2016-04-17 19:03:51.537968+00
2417	125	56	Red	0	2016-04-17 19:04:02.466734+00
2419	125	56	Purple	0	2016-04-17 19:04:02.480311+00
2421	125	56	Yellow	1	2016-04-17 19:04:10.689153+00
2422	125	58	Blue Wave (Dark purple)	0	2016-04-17 19:05:01.962261+00
2424	125	58	Pink Wave	0	2016-04-17 19:05:01.97719+00
2426	125	58	Purple Wave (Magenta)	0	2016-04-17 19:05:02.011229+00
2427	125	60	Beefsteak	0	2016-04-17 19:05:17.759093+00
2429	125	60	Big Boy	0	2016-04-17 19:05:17.771689+00
2434	125	61	Dill	0	2016-04-17 19:05:32.527542+00
2436	125	61	Oregano (Italian)	0	2016-04-17 19:05:32.569388+00
2432	125	61	Parsley	1	2016-04-17 19:05:45.100857+00
2438	126	1	\N	2	2016-04-17 19:08:00.29859+00
2439	126	4	\N	2	2016-04-17 19:08:08.083051+00
2484	98	27	Purple	1	2016-04-18 01:05:20.987806+00
2441	110	11	2 pink, 2 purple	4	2016-04-18 00:11:23.631887+00
2442	110	19	\N	3	2016-04-18 00:11:39.580143+00
2443	110	61	Cilantro	0	2016-04-18 00:11:59.031935+00
2444	110	61	Parsley	0	2016-04-18 00:11:59.129663+00
2447	110	61	Dill	0	2016-04-18 00:11:59.349919+00
2448	110	61	Oregano (Italian)	0	2016-04-18 00:11:59.359783+00
2449	110	61	Mint	1	2016-04-18 00:12:07.788902+00
2446	110	61	Thyme	2	2016-04-18 00:12:12.69075+00
2445	110	61	Basil (Sweet Italian)	1	2016-04-18 00:12:18.19873+00
2450	98	56	Red	0	2016-04-18 00:15:29.489206+00
2451	98	56	Purple	2	2016-04-18 00:15:29.574803+00
2452	98	56	White	3	2016-04-18 00:15:29.642975+00
2453	98	56	Pink	0	2016-04-18 00:15:29.703608+00
2454	98	56	Yellow	4	2016-04-18 00:15:29.730744+00
2456	98	47	Silver	1	2016-04-18 00:17:31.058676+00
2455	98	46	Mixed	1	2016-04-18 00:17:33.747464+00
2458	98	50	\N	14	2016-04-18 00:18:17.586187+00
2457	98	48	\N	4	2016-04-18 00:18:28.360415+00
2459	96	21	\N	3	2016-04-18 00:21:22.184731+00
1896	96	60	Sweet 100 (cherry tomatoes)	1	2016-04-18 00:21:44.201637+00
2460	96	61	Basil (Sweet Italian)	0	2016-04-18 00:21:58.394057+00
2461	96	61	Parsley	0	2016-04-18 00:21:58.394938+00
2464	96	61	Thyme	0	2016-04-18 00:21:58.423034+00
2465	96	61	Oregano (Italian)	0	2016-04-18 00:21:58.42387+00
2466	96	61	Mint	0	2016-04-18 00:21:58.439894+00
2463	96	61	Cilantro	1	2016-04-18 00:22:04.107948+00
2462	96	61	Dill	1	2016-04-18 00:22:06.988219+00
2467	127	58	Blue Wave (Dark purple)	0	2016-04-18 00:31:49.394204+00
2468	127	58	Red Wave	0	2016-04-18 00:31:49.479898+00
2469	127	58	Pink Wave	0	2016-04-18 00:31:49.518534+00
2471	127	58	Purple Wave (Magenta)	1	2016-04-18 00:31:57.478858+00
2470	127	58	White Wave	1	2016-04-18 00:32:02.711164+00
2472	127	51	\N	3	2016-04-18 00:32:22.070209+00
2473	128	19	\N	1	2016-04-18 00:34:06.762504+00
2474	128	21	\N	1	2016-04-18 00:34:12.719186+00
2475	128	39	Purple	0	2016-04-18 00:34:29.819584+00
2476	128	39	Red	0	2016-04-18 00:34:29.914292+00
2477	128	39	Yellow	0	2016-04-18 00:34:29.989147+00
2478	128	39	Pink	0	2016-04-18 00:34:30.052469+00
2479	128	39	White	0	2016-04-18 00:34:30.090526+00
2480	128	39	Mixed	1	2016-04-18 00:34:37.25744+00
2481	83	6	New Guinea Impatiens (lavender or magenta)	0	2016-04-18 01:01:10.37324+00
2483	83	6	or Begonia (big)--red	0	2016-04-18 01:01:10.422552+00
2482	83	6	Go-Go Begonia-red w/creeping jenny or yellow w/silver dichondra	1	2016-04-18 01:01:30.433772+00
2485	98	27	White	0	2016-04-18 01:05:05.239337+00
2487	98	33	Bonanza Bee (Yellow-orange)	0	2016-04-18 01:05:11.553226+00
2488	98	33	Bonanza Mixed	0	2016-04-18 01:05:11.565085+00
2489	98	33	Bonanza Orange	0	2016-04-18 01:05:11.565849+00
2486	98	33	Bonanza Yellow	1	2016-04-18 01:05:31.36587+00
2490	98	56	Red	0	2016-04-18 01:07:29.608488+00
2493	98	56	Pink	0	2016-04-18 01:07:29.722239+00
2495	98	41	Dwarf Mixed	1	2016-04-18 01:16:55.148327+00
2496	98	41	Tall Mixed	0	2016-04-18 01:16:55.194796+00
2497	109	61	Cilantro	0	2016-04-18 01:36:05.035978+00
2498	109	61	Parsley	0	2016-04-18 01:36:05.139314+00
2500	109	61	Thyme	0	2016-04-18 01:36:05.253341+00
2501	109	61	Dill	0	2016-04-18 01:36:05.262657+00
2502	109	61	Oregano (Italian)	0	2016-04-18 01:36:05.265666+00
2503	109	61	Mint	0	2016-04-18 01:36:05.278873+00
2499	109	61	Basil (Sweet Italian)	1	2016-04-18 01:36:12.183829+00
2505	131	52	Violet (Hot Pink)	0	2016-04-18 11:16:20.001947+00
2507	131	52	Pink	2	2016-04-18 11:16:26.067361+00
2506	131	52	Deep Red	1	2016-04-18 11:16:31.258203+00
2508	131	52	White	1	2016-04-18 11:16:33.507793+00
2509	131	48	\N	2	2016-04-18 11:16:55.160297+00
2512	131	59	Red Bell	0	2016-04-18 11:17:07.418695+00
2513	131	59	Jalapeno	0	2016-04-18 11:17:07.422155+00
2511	131	59	Green Bell	1	2016-04-18 11:17:11.137408+00
2510	131	59	Yellow Bell	1	2016-04-18 11:17:15.09632+00
2515	132	20	\N	2	2016-04-18 11:21:18.44533+00
2517	132	3	\N	1	2016-04-18 11:21:38.007309+00
2518	132	5	Geranium w spike (white, magenta, pink, or coral)	0	2016-04-18 11:21:51.376559+00
2520	132	5	or Gerbera Daisy mix	0	2016-04-18 11:21:51.494618+00
2519	132	5	Wave petunia mix - red, white, and dark purple	2	2016-04-18 11:21:58.156355+00
2521	132	51	\N	6	2016-04-18 11:22:32.627758+00
2522	132	58	Blue Wave (Dark purple)	0	2016-04-18 11:25:43.887188+00
2523	132	58	Red Wave	0	2016-04-18 11:25:43.909169+00
2524	132	58	Pink Wave	0	2016-04-18 11:25:43.919113+00
2525	132	58	White Wave	0	2016-04-18 11:25:43.925881+00
2526	132	58	Purple Wave (Magenta)	1	2016-04-18 11:25:52.454075+00
2527	132	4	\N	1	2016-04-18 11:26:23.359713+00
2528	132	60	Beefsteak	0	2016-04-18 11:26:47.418329+00
2529	132	60	Roma	2	2016-04-18 11:27:06.665403+00
2530	132	60	Big Boy	2	2016-04-18 11:27:22.005477+00
2531	132	60	Sweet 100 (cherry tomatoes)	4	2016-04-18 11:27:00.165624+00
2541	56	58	Red Wave	0	2016-04-18 11:29:48.856626+00
2543	56	58	White Wave	0	2016-04-18 11:29:48.911986+00
2539	56	4	\N	2	2016-04-18 13:23:19.372666+00
2542	56	58	Pink Wave	0	2016-04-18 11:29:48.905549+00
2544	56	58	Purple Wave (Magenta)	0	2016-04-18 11:29:48.917279+00
2540	56	58	Blue Wave (Dark purple)	1	2016-04-18 11:30:00.377873+00
2557	133	28	Bronze Leaf Red	0	2016-04-18 13:00:08.154624+00
2559	133	28	Bronze Leaf White	0	2016-04-18 13:00:08.168931+00
2560	133	28	Bronze Leaf Mixed	0	2016-04-18 13:00:08.17701+00
2561	133	28	Green Leaf Red	0	2016-04-18 13:00:08.187086+00
2562	133	28	Green Leaf Rose/Pink	0	2016-04-18 13:00:08.19031+00
2563	133	28	Green Leaf White	0	2016-04-18 13:00:08.221697+00
2565	133	58	Blue Wave (Dark purple)	0	2016-04-18 13:00:29.295988+00
2566	133	58	Red Wave	0	2016-04-18 13:00:29.316682+00
2567	133	58	Pink Wave	0	2016-04-18 13:00:29.32083+00
2568	133	58	White Wave	0	2016-04-18 13:00:29.332357+00
2569	133	58	Purple Wave (Magenta)	2	2016-04-18 13:00:38.045264+00
2558	133	28	Bronze Leaf Rose/Pink	0	2016-04-18 13:00:54.202924+00
2564	133	28	Green Leaf Mixed	1	2016-04-18 13:00:59.738362+00
2570	56	56	Purple	0	2016-04-18 13:21:23.180101+00
2571	56	56	Red	0	2016-04-18 13:21:23.181939+00
2572	56	56	Pink	0	2016-04-18 13:21:23.195168+00
2573	56	56	White	0	2016-04-18 13:21:23.196251+00
2574	56	56	Yellow	2	2016-04-18 13:21:39.83525+00
2576	56	5	Wave petunia mix - red, white, and dark purple	0	2016-04-18 13:23:41.477876+00
2577	56	5	or Gerbera Daisy mix	0	2016-04-18 13:23:41.494608+00
2575	56	5	Geranium w spike (white, magenta, pink, or coral)	2	2016-04-18 13:24:37.424082+00
2579	56	20	\N	2	2016-04-18 13:26:48.40309+00
\.


--
-- Name: plants_orderitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docker
--

SELECT pg_catalog.setval('plants_orderitem_id_seq', 2580, true);


--
-- Data for Name: plants_plant; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY plants_plant (id, name, description, cost, color_limits, color_preference, notes, sun, type, img_url, marketing) FROM stdin;
1	(#1)  Dark Red Geranium w/spike	\N	15	Dark Red	f	\N	Sun	10" PREMIUM COMBINATION PATIO POTS	http://www.iserv.net/v4files/meadowridge/Dark%20Red%20Geranium%20Spike%20sm.jpg	\N
5	Assorted Sun Combo	\N	15	 Geranium w spike (white, magenta, pink, or coral); Wave petunia mix - red, white, and dark purple; or Gerbera Daisy mix	t	Supplier will send assorted plants/colors--we'll try to match your preference but can't guarantee it.	Sun	10" PREMIUM COMBINATION PATIO POTS	http://www.onlineplantguide.com/Image%20Library/P/8785.jpg	\N
6	Assorted Shade Combo	\N	15	 New Guinea Impatiens (lavender or magenta); Go-Go Begonia-red w/creeping jenny or yellow w/silver dichondra; or Begonia (big)--red	t	Supplier will send assorted plants/colors--we'll try to match your preference but can't guarantee it.	Shade	10" PREMIUM COMBINATION PATIO POTS	http://www.american-farms.com/photogallery/harmony%20dark%20lavender%204.JPG	\N
7	Begonia	\N	13	\N	t	* Supplier delivers various colors; you may list your color preference (ie. pink or red, etc.) and we'll try to match it, but can't guarantee it	Shade	10" HANGING BASKETS	http://www.susansgardenpatch.com/annualswaxedbegonias.jpg	Nowhere to hang a basket?  Drop any basket in your favorite pot and remove the hangers!
8	Black Eyed Susan Vine	\N	13	\N	t	* Supplier delivers various colors; you may list your color preference (ie. pink or red, etc.) and we'll try to match it, but can't guarantee it	Sun	10" HANGING BASKETS	http://www.edenbrothers.com/store/media/_Multiple-Images/resized/SFBES17-1_medium.jpg	Nowhere to hang a basket?  Drop any basket in your favorite pot and remove the hangers!
9	Impatiens 	\N	13	\N	t	* Supplier delivers various colors; you may list your color preference (ie. pink or red, etc.) and we'll try to match it, but can't guarantee it	Shade	10" HANGING BASKETS	https://www.meadowsfarms.com/images/Retail/Plants/Annuals/Impatiens-walleriana.aspx	Nowhere to hang a basket?  Drop any basket in your favorite pot and remove the hangers!
11	Calibrachoa (Million Bells)	\N	13	\N	t	* Supplier delivers various colors; you may list your color preference (ie. pink or red, etc.) and we'll try to match it, but can't guarantee it	Sun	10" HANGING BASKETS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/54280.jpg	Nowhere to hang a basket?  Drop any basket in your favorite pot and remove the hangers!
13	Ivy Geranium	\N	13	\N	t	* Supplier delivers various colors; you may list your color preference (ie. pink or red, etc.) and we'll try to match it, but can't guarantee it	Sun	10" HANGING BASKETS	https://c2.provenwinners.com/sites/provenwinners.com/files/images/professional/growers/boldly_scarlet_fire_mono.jpg	Nowhere to hang a basket?  Drop any basket in your favorite pot and remove the hangers!
18	(#1) Pink/White Combo	Twister pink verbena, pink calibrachoa, white bacopa	15	\N	f	\N	Sun	10" COMBINATION HANGING BASKETS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/5936_29.jpg	Beautiful gift idea for Mother's Day!
19	(#2) Purple/Yellow Combo	Dark purple calibrachoa, yellow bidens, lavender bacopa	15	\N	f	\N	Sun	10" COMBINATION HANGING BASKETS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/superbells_blue_0.jpg	Beautiful gift idea for Mother's Day!
20	(#3) Pink/Purple Combo	Light pink calibrachoa, purple & white petunia, pink verbena	15	\N	f	\N	Sun	10" COMBINATION HANGING BASKETS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/supertunia_royal_velvet_0.jpg	Beautiful gift idea for Mother's Day!
21	(#4) Yellow/White Combo	Yellow calibrachoa, purple w/ white petunia, white verbena	15	\N	f	\N	Sun	10" COMBINATION HANGING BASKETS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/111361.jpg	Beautiful gift idea for Mother's Day!
4	(#8) Summer Mix- verbena, petunia, calibrachoa	\N	15	Blue verbena, red petunia, apricot calibrachoa	f	\N	Sun	10" PREMIUM COMBINATION PATIO POTS	https://s-media-cache-ak0.pinimg.com/236x/22/72/83/22728352b1901c4aa80ed67d22966e43.jpg	\N
2	(#6) Cool Colors- Petunia, Verbena, Calibrachoa	\N	15	Dark purple calibrachoa, sky blue petunia, lt. blue verbena	f	\N	Sun	10" PREMIUM COMBINATION PATIO POTS	http://www.whiteflowerfarm.com/mas_assets/cache/image/4/d/0/1232.Jpg	\N
14	Double Impatiens	\N	13	\N	t	* Supplier delivers various colors; you may list your color preference (ie. pink or red, etc.) and we'll try to match it, but can't guarantee it	Shade	10" HANGING BASKETS	https://millstplants.s3.amazonaws.com/DoubleImpatiens.png	Nowhere to hang a basket?  Drop any basket in your favorite pot and remove the hangers!
17	Streptocarpella - Blue  	\N	13	\N	f	* Supplier delivers various colors; you may list your color preference (ie. pink or red, etc.) and we'll try to match it, but can't guarantee it	Shade	10" HANGING BASKETS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/19696.jpg	Nowhere to hang a basket?  Drop any basket in your favorite pot and remove the hangers!
12	Fuchsia	\N	13	\N	f	* Supplier delivers various colors; you may list your color preference (ie. pink or red, etc.) and we'll try to match it, but can't guarantee it	Shade	10" HANGING BASKETS	https://millstplants.s3.amazonaws.com/Fuchsia.png	Nowhere to hang a basket?  Drop any basket in your favorite pot and remove the hangers!
15	Lobelia	\N	13	\N	f	* Supplier delivers various colors; you may list your color preference (ie. pink or red, etc.) and we'll try to match it, but can't guarantee it	Part Sun	10" HANGING BASKETS	https://millstplants.s3.amazonaws.com/Lobelia.png	Nowhere to hang a basket?  Drop any basket in your favorite pot and remove the hangers!
16	New Guinea Impatiens	\N	13	\N	t	* Supplier delivers various colors; you may list your color preference (ie. pink or red, etc.) and we'll try to match it, but can't guarantee it	Shade	10" HANGING BASKETS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/70727.jpg	Nowhere to hang a basket?  Drop any basket in your favorite pot and remove the hangers!
22	(#5)  Pink Combo	Deep pink calibrachoa, purple rose petunia, dark pink verbena	15	\N	f	\N	Sun	10" COMBINATION HANGING BASKETS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/54280.jpg	Beautiful gift idea for Mother's Day!
23	(#6)  Red/White Combo	Red geranium, white verbena	15	\N	f	\N	Sun	10" COMBINATION HANGING BASKETS	http://www.powerflowers.com/files/images/fire%20and%20ice%202015%20w%20logo%20web.jpg	Beautiful gift idea for Mother's Day!
24	(#7)  Double Impatiens	Pink, purple and white double impatiens	15	\N	f	\N	Shade	10" COMBINATION HANGING BASKETS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/max_width/ifa_upload/rockapulco_white_0.jpg	Beautiful gift idea for Mother's Day!
25	(#8)  SHADE Combo	Non-stop Begonia (in various colors) & creeping jenny (lime green)	15	\N	f	\N	Shade	10" COMBINATION HANGING BASKETS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/101645.jpg	Beautiful gift idea for Mother's Day!
26	Impatiens	\N	13	Blue Pearl (pastel lt.purple);Lilac (deep purple/pink);Lipstick (Hot Pink);Pink;Red;Salmon;Violet (dk. violet/purple);White;Mixed	t	\N	Shade	FLATS OF ANNUALS	http://www.american-farms.com/photogallery/se%20blue%20pearl%20bed.JPG	\N
27	Alyssum	\N	13	Purple;White	t	\N	Sun	FLATS OF ANNUALS	http://northamericanfarmer.com/flower-patch/images/flower/Alyssum.jpg	\N
28	Begonias 	\N	13	Bronze Leaf Red;Bronze Leaf Rose/Pink;Bronze Leaf White;Bronze Leaf Mixed;Green Leaf Red;Green Leaf Rose/Pink;Green Leaf White;Green Leaf Mixed	t	\N	Shade	FLATS OF ANNUALS	http://thumbs.dreamstime.com/x/flower-begonia-21591513.jpg	\N
29	Cosmos (Mixed)	\N	13	\N	f	\N	Sun	FLATS OF ANNUALS	https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcRccuFCSMAh98AyN-ueMjqP-l6WqFSWfRWID2yzumIDeexFlm3Qeg	\N
30	Dahlia (Mixed)	\N	13	\N	f	\N	Sun	FLATS OF ANNUALS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/dahlightful_lively_lavender_tagimage_0.jpg	\N
31	Dianthus (Mixed)	\N	13	\N	f	\N	Sun	FLATS OF ANNUALS	https://c2.provenwinners.com/sites/provenwinners.com/files/images/articles/dianthus-coconut-punch.jpg	\N
32	Lobelia	\N	13	Blue	t	\N	Part Sun	FLATS OF ANNUALS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/93318.jpg	\N
33	Marigolds	\N	13	Bonanza Bee (Yellow-orange);Bonanza Yellow;Bonanza Orange;Bonanza Mixed	t	\N	Sun	FLATS OF ANNUALS	http://www.2bseeds.com/images/marigoldbonanzabolero.jpg	\N
34	Hybrid Marigolds	\N	13	Orange;Yellow;Vanilla (Sweet Cream)	t	\N	Sun	FLATS OF ANNUALS	http://demandware.edgesuite.net/sits_pod38/dw/image/v2/ABAQ_PRD/on/demandware.static/-/Sites-masterCatalog_Burpee/default/dw232efacc/Images/Product%20Images/prod000265/prod000265.jpg?sw=322&sh=380&sm=fit	\N
35	Moss Rose (Mixed)	\N	13	\N	f	\N	Sun	FLATS OF ANNUALS	http://www.gardencrossings.com/_ccLib/image/plants/DETA-1927.jpg	\N
37	Pansy  (Mixed)	\N	13	\N	f	\N	Part Sun	FLATS OF ANNUALS	https://s-media-cache-ak0.pinimg.com/736x/09/38/29/093829688069ac936d8c59bdcd99008f.jpg	\N
38	Double Petunia  (Mixed)	\N	13	\N	f	\N	Sun	FLATS OF ANNUALS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/5179_20.jpg	\N
39	Petunias	\N	13	Purple;Red;Yellow;Pink;White;Mixed	t	\N	Sun	FLATS OF ANNUALS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/supertunia_mini_rose_veined_improved.jpg	\N
40	Salvia	\N	13	Red;Tall Red;Victoria Blue	t	\N	Sun	FLATS OF ANNUALS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/pw_salvia_playin_the_blues.jpg	\N
42	Vinca	\N	13	Mixed;Red;White/Eye	t	\N	Sun	FLATS OF ANNUALS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/coracascadecherr_tag_02.jpg	\N
43	Zinnia	\N	13	Dwarf Mixed	t	\N	Sun	FLATS OF ANNUALS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/zinniamagellanyellow_1.jpg	\N
44	Coleus	\N	13	Mixed	t	\N	Shade	FLATS OF ANNUALS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/19889.jpg	\N
45	Dusty Miller	\N	13	Silver	t	\N	Sun	FLATS OF ANNUALS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/19384.jpg	\N
46	Coleus:  1/2 Flat	\N	7	Mixed	t	\N	Shade	FLATS OF ANNUALS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/19889.jpg	\N
47	Dusty Miller:  1/2 Flat	\N	7	Silver	t	\N	Sun	FLATS OF ANNUALS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/19384.jpg	\N
49	Sprengeri	\N	2	\N	f	\N	\N	GREENS OR SPIKES - 3.5" POTS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/asparagusspringeri.jpg	\N
50	Vinca Vine	\N	2	\N	f	\N	\N	GREENS OR SPIKES - 3.5" POTS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/48061.jpg	\N
51	Green Ipomea (Sweet Potato Vine)	\N	2	\N	f	\N	\N	GREENS OR SPIKES - 3.5" POTS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/5463_30.jpg	\N
53	Double Impatiens	\N	4	Pink;Lavender;Salmon;White	t	\N	Shade	4.3" PREMIUM ANNUAL POTS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/rockapulco_rose_0.jpg	\N
55	Bacopa	\N	4	White	t	\N	Part Sun	4.3" PREMIUM ANNUAL POTS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/83120.jpg	\N
56	Calibrachoa	\N	4	Red;Purple;White;Pink;Yellow	t	\N	Sun	4.3" PREMIUM ANNUAL POTS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/66586.jpg	\N
41	Snapdragon	\N	13	Dwarf Mixed;Tall Mixed	t	\N	Sun	FLATS OF ANNUALS	https://millstplants.s3.amazonaws.com/SnapDragon.png	\N
48	Spikes	\N	2	\N	f	\N	\N	GREENS OR SPIKES - 3.5" POTS	https://millstplants.s3.amazonaws.com/Greens.png	\N
52	Geraniums	\N	1.5	Violet (Hot Pink);Deep Red;Pink;White	t	\N	Sun	4" POTTED GERANIUMS	https://millstplants.s3.amazonaws.com/PottedGeraniums.png	\N
54	New Guinea Impatiens	\N	4	White;Pink;Purple;Red;Lavender	t	\N	Part Sun	4.3" PREMIUM ANNUAL POTS	https://millstplants.s3.amazonaws.com/NewGuineaImpatiens.png	\N
57	Gerbera Daisy 	\N	4	Mixed	t	\N	Sun	4.3" PREMIUM ANNUAL POTS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/hello_magentamen_tagimage.jpg	\N
59	Peppers	\N	2	Green Bell;Yellow Bell;Red Bell;Jalapeno	t	\N	\N	VEGETABLES  - 4 plants per cluster	http://www.parkswholesaleplants.com/wp-content/uploads/2009/02/Jupiter-Green-Bell-Pepper.jpg	These vegetables are 50 cents a plant!!!  Great deal!!
60	Tomatoes	\N	2	Beefsteak;Roma;Big Boy;Sweet 100 (cherry tomatoes)	t	\N	\N	VEGETABLES  - 4 plants per cluster	http://www.whiteflowerfarm.com/mas_assets/cache/image/9/1/3/2323.Jpg	These vegetables are 50 cents a plant!!!  Great deal!!
61	Herbs	\N	4	Cilantro;Parsley;Basil (Sweet Italian);Dill;Thyme;Oregano (Italian);Mint	t	\N	\N	**HERBS** - 4" potted herbs	http://3.bp.blogspot.com/-LjV_a_jZQow/TcoqwzauAUI/AAAAAAAABpI/54M-86rgvLQ/s1600/HealthBenefits-of-Parsley-and-Cilantro.jpg	\N
3	(#7) Pink Blossom- calibrachoa, verbena	\N	15	Pink calibrachoa, rasberry verbena, bright pink petunia	f	\N	Sun	10" PREMIUM COMBINATION PATIO POTS	https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/low-resolution/ifa_upload/national_combo_spring_2016.jpg?1456421870	\N
10	Boston Fern	\N	13	\N	f	* Supplier delivers various colors; you may list your color preference (ie. pink or red, etc.) and we'll try to match it, but can't guarantee it	Shade	10" HANGING BASKETS	http://bloomiq.com/sites/bloomiq.com/files/imagecache/plant_375px_wide_310px_heigh/123476.003.jpg	Nowhere to hang a basket?  Drop any basket in your favorite pot and remove the hangers!
36	Nicotiana  (Mixed)	\N	13	\N	f	\N	Sun	FLATS OF ANNUALS	https://millstplants.s3.amazonaws.com/Nicotiana.png	\N
58	Wave Petunias	\N	8	Blue Wave (Dark purple);Red Wave;Pink Wave;White Wave;Purple Wave (Magenta)	t	\N	Sun	3" POTTED WAVE PETUNIAS - 6 pots per pack	https://millstplants.s3.amazonaws.com/WavePetunias.png	\N
\.


--
-- Name: plants_plant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docker
--

SELECT pg_catalog.setval('plants_plant_id_seq', 61, true);


--
-- Data for Name: plants_stakeholder; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY plants_stakeholder (id, email, password, last_login, is_active, is_staff, name, phone, times, volunteer) FROM stdin;
70	corbett.mary@gmail.com	pbkdf2_sha256$24000$pnL1zDqvuLUz$eiQzk/Kpdj8BVXORgBHtR9VKHj4RZEtXjHVzciXPgKI=	2016-03-27 22:57:39.686131+00	t	f	Mary Corbett	6308538498	\N	f
83	sarahgibson@hotmail.com	pbkdf2_sha256$24000$B7Sj12905imy$mx4TQXQv37NkVrsVWE0v9K2s+gJguLt87ndjZPL4atY=	2016-04-18 16:01:36.44546+00	t	f	Sarah Gibson	6306642748	All red sun combo	t
77	katydid8651@gmail.com	pbkdf2_sha256$24000$xXixiYLX031p$g70121fp8A+NJLhVNHpFZX3OyYKbiSBL8JQf7WCqZ3w=	2016-04-07 19:45:40.281563+00	t	f	Kaitlyn Chadwell	8122403269	\N	f
71	hayes.jessica426@yahoo.com	pbkdf2_sha256$24000$5jw6wu96DcGw$u7K24UB0TDp9zqSXdK3SdjqDl+gJSvCDeDjnNErBEZg=	2016-03-31 15:24:24.776035+00	t	f	Jessica Hayes	6309155377	\N	f
81	mcclaurins@yahoo.com	pbkdf2_sha256$24000$oHN35cyXD2aS$3YoWIZiGtg3cuzM4leAi7mIZEQi1Tg5JD/AN/sjMjTw=	2016-04-06 14:23:19.4817+00	t	f	Diana McClaurin	630-301-2144	\N	f
172	sharihelms@example.com	pbkdf2_sha256$24000$HRLInpntVVwX$s+00Zlacojq4tVG7+EyE4bHT4Cm0dk/ZtwQ/MUJ7QEQ=	2016-04-18 00:31:27.838082+00	t	f	Shari Helms (St.Tims)	6303191952	\N	f
72	ellencmrn@yahoo.com	pbkdf2_sha256$24000$Aud4YM910hKV$tY62BRv6M2+/fguvb5HGZ4TkD4Hat0Rj7DlfQyJOIN8=	2016-04-01 17:49:00.988345+00	t	f	Ellen Cameron	810-730-9545	\N	f
173	kimrunge@example.com	pbkdf2_sha256$24000$XsRtlRciRSVz$IOb+8ZwkJTlaalVNMG5zAjuh6kAo8CA9/YHQSF1bKQk=	2016-04-18 00:33:54.422203+00	t	f	Kim Runge (ST)	7088561201	\N	f
90	caredlin1736@yahoo.com	pbkdf2_sha256$24000$lqB6EcmHpcLs$ICtryjxTrZ3w/Mnq+CDivnyX7wz0Tr4Rp9F0iCQFybI=	2016-04-06 22:39:19.036599+00	t	f	Cindy Boyer	6308545198	Unloading - only available until 9:00	t
1		pbkdf2_sha256$24000$IiRPZXfMasFy$DkzJol5+wonlTcMIujySSMwA0sI51UvBtaNPH5pjcnM=	2016-03-16 19:13:59.339498+00	t	f	Laura Thorne	630-548-2285	\N	t
84	admin@millstplantsale.com	pbkdf2_sha256$24000$pngFwBIKArkC$21bYaHhbSAwZ6nl6YScI99BEaUcffRSLYv+f7i+sKnE=	2016-04-19 10:57:11.025814+00	t	t	Peppers	\N	\N	f
179	gibsonenvironmental@yahoo.com	pbkdf2_sha256$24000$uRwemA1g7xdV$lXgwxr4hszG/kR0GMJksHwVgk3sUEuTHFNY8FIpXY44=	2016-04-18 16:02:04.668309+00	t	f	Sarah Gibson	\N	\N	f
65	karalee.anderson@gmail.com	pbkdf2_sha256$24000$7BMo5tWZZSUA$1U3h1ZdxzMMcc3ANCHR1wrYQDx9H616D2XX/KmoHohE=	2016-04-04 02:34:48.006849+00	t	f	KaraLee Anderson	425-516-2913	organizing	t
87	emmylou93@yahoo.com	pbkdf2_sha256$24000$9FBBrxlh1vZY$zgfhKeNu8kwzSEAva7YnCj4XFHPRjOBFjng7oHIMDvw=	2016-04-06 19:16:19.483613+00	t	f	Emily Achtstatter	312-515-3714	6 a.m. - 8 a.m.	t
74	rkuber2003@yahoo.com	pbkdf2_sha256$24000$sXjOTh85Bz2X$1kVPF2NkOe87ml1Mmphj1iqkYbcixj7imgehIzBdeG4=	2016-04-04 19:23:06.70124+00	t	f	Rebecca Flood	630-234-4876	\N	f
105	mkloog@ymcachicago.org	pbkdf2_sha256$24000$9gBXYYQuNw3K$7CgvPHpXrqyha+QGzR0flTHyO4wmbdNitJl3nreSoF0=	2016-04-11 13:43:32.554798+00	t	f	Melissa Siomos	630-430-5941	\N	f
93	susan.stellmacher@gmail.com	pbkdf2_sha256$24000$mssbH3XMxULN$v0vVpZrUVzyl3s9XKNDCg4oCRSsclAMMCIeN6ngJokM=	2016-04-08 02:58:31.027178+00	t	f	Susan Stellmacher	9203584689	\N	f
79	darladriggs@sbcglobal.net	pbkdf2_sha256$24000$yfxbgsOJTsFS$L9jP9He6hw9iRi5+dywS+nEcA8WNac0p+JMb4PADUqc=	2016-04-05 18:05:06.408431+00	t	f	Darla Driggs	630-405-9083	\N	f
75	ginny@sneakypockets.com	pbkdf2_sha256$24000$ivK17EM0X0OB$ydLl+mWUL3evM5RUwVR2+hS0US8uXJDPgmW6u+m4M9w=	2016-04-04 23:56:23.88509+00	t	f	Ginny Hemmeter	630-207-7062	9 - 11 am	t
88	jennie15@gmail.com	pbkdf2_sha256$24000$wluCjvfoXE6l$Dj2bVLFNz00IwkjWjtvehdK4LYIFFZyzwV5dfgdHzK4=	2016-04-06 20:17:56.675148+00	t	f	Jennifer Chaney	708-562-1236	\N	f
78	susanczochara@yahoo.com	pbkdf2_sha256$24000$rkUgUlT3mYOO$9moQLIFVAkDi9Br8BJLcCMJse2v4Q2rFVgtIygXr/8s=	2016-04-08 13:15:34.19925+00	t	f	Susan Czochara	630-777-8971	\N	f
80	cindy.meerman@gmail.com	pbkdf2_sha256$24000$cOLFAdYyHfDL$e8QT9nYKnSwIVyXg301I4dGsoRdsinpRt7SgXgtWEZs=	2016-04-06 21:14:15.580738+00	t	f	Cindy Meerman	630 428-1485	\N	f
103	derek.krauss@veolia.com	pbkdf2_sha256$24000$4FSWMDTqaQMg$GUqoydQL1MKaqZktRr3LwIlXvzUlZy+KuTcWwExvd2g=	2016-04-09 02:49:21.66751+00	t	f	Derek Krauss	630-369-0953	\N	f
86	hqueen22@hotmail.com	pbkdf2_sha256$24000$VppH4yzIKukW$4h/1l1Nl+jEbsf4pKYWrJ2a9my2YcWeo4ik8gDQjztU=	2016-04-06 17:00:25.684035+00	t	f	Heather Queen	630-885-8577	\N	f
66	rileydietz@gmail.com	pbkdf2_sha256$24000$a7IjhCJ4Bn7D$bE1a9ysD5nfpj++0ps1vF1jWsGC86wHJZbDaAso4Qhc=	2016-03-24 01:51:20.771209+00	t	f	Jennifer Dietz	3125607624	\N	f
99	kradowski@yahoo.com	pbkdf2_sha256$24000$gb6PXKKTSq3v$QnTPhlW8GNRo2129dnzyUajtMFn8e6ea0JpwiP6jvwM=	2016-04-08 17:17:13.260388+00	t	f	Kristie Coyle	3123990640	\N	f
69	wootay11@gmail.com	pbkdf2_sha256$24000$ihIXQwSQBll9$LylM8jty9lEgpxXUWBoMmqofsvQZm3+PAQeMbAno7t4=	2016-03-27 14:51:50.33911+00	t	f	Martinique Wood	630-276-9676	\N	f
92	c.drendel@aol.com	pbkdf2_sha256$24000$9xNDcAAnvwvV$77RWxq/qG/PL3xufd+mkXZm7SpD99h79+ju42x1MZNM=	2016-04-07 19:21:57.082095+00	t	f	Crissy Drendel	630-329-4009	\N	f
95	rjsrose@msn.com	pbkdf2_sha256$24000$s7Zzgmj9roLf$CoX+Yln8dNI6lmAQlMWrBOaxyokOzEGITi8N9vgR53M=	2016-04-08 15:03:18.862278+00	t	f	\N	\N	\N	f
100	oberweis@oberweis.net	pbkdf2_sha256$24000$saNOdMTFhOeD$LAh5oLPzzBxeAhOSK0d58I4/3CBT5oO21TgHP0KwT3s=	2016-04-08 17:35:14.541618+00	t	f	Jim & Ashleigh Oberweis	6307780702	\N	f
102	derek_krauss@hotmail.com	pbkdf2_sha256$24000$FT04IYrcbPt6$xy8HNeBqgoz3GAX5VEKbmt6eUxKLRO6tkjUUZa4OaS0=	2016-04-09 01:50:38.963848+00	t	f	Derek Krauss	63036909530	\N	f
101	tyrahawkins@gmail.com	pbkdf2_sha256$24000$JbVrdUghWc25$AjPjgRsz89yvIIWoL5VQ/LN7Qv6bofgxurMOnR/fDPs=	2016-04-08 18:46:16.333875+00	t	f	Tyra hawkins	908-723-7544	\N	f
104	lynpez@aol.com	pbkdf2_sha256$24000$n54dq2xUkvWa$OdEWwSB9WZKtp56U5DmxVlJA6qvMsBzObynqgZrlCGE=	2016-04-09 15:52:52.871576+00	t	f	Lynn Pezza	630-649-4560	\N	f
107	amyswia@hotmail.com	pbkdf2_sha256$24000$x8HHObKFfetH$+2bI6DtnH2h13OLUhL6hrWhlI2KmHGcqkJ3+64Fyi4E=	2016-04-12 12:50:24.076995+00	t	f	Amy Swiatek	8478586806	\N	f
109	mbnagai@yahoo.com	pbkdf2_sha256$24000$VLYmt7qOLiUM$LrW+NuVcSftoHmrbdMYj2Gi8O0dJ+hZv2D/PAQ1azYg=	2016-04-13 00:10:51.276777+00	t	f	Mary Beth Nagai	630-718-1138	\N	f
112	sassybeallis@hotmail.com	pbkdf2_sha256$24000$0Gsg1g7KwKxM$WpOIOjjyBzK1QKv7XFrDve4F3DsuypJI2nizmXoU8qw=	2016-04-13 02:15:34.515229+00	t	f	Sonja Beallis	8157910236	\N	f
113	mjimenezbiles@yahoo.com	pbkdf2_sha256$24000$2Db7hosp5nWo$r6uuzgvN5ZfcLcw1thZGvz9aJkzQEQaL9wzEVgC0h+U=	2016-04-13 04:49:03.470318+00	t	f	Melissa Biles	630-460-1981	\N	f
114	chess@imprint-e.com	pbkdf2_sha256$24000$unrqeC634XXc$VDjPurAnyvh6YxMzcd5PehhI368f0mEN/FpihoHR2Vs=	2016-04-13 13:19:08.500163+00	t	f	Carrie Hess	6308535192	\N	f
106	llodens@gmail.com	pbkdf2_sha256$24000$WeUr5UWzeKyp$ELcLP+Zdgwr7ld4tBOrtxtJNSJdK/7T+V5un1ox4KE8=	2016-04-13 15:51:20.959559+00	t	f	Leilani Lodens	630-579-9792	\N	f
117	dana.bussing@gmail.com	pbkdf2_sha256$24000$XiJvgBskRoFz$56Knkir60+OyTBM/mEwSwocs5LId6Xy9uuiULqNWphg=	2016-04-13 19:06:33.1216+00	t	f	Dana Bussing	708-903-9381	\N	f
110	marni_springer@yahoo.com	pbkdf2_sha256$24000$iMuT1v8cMNXj$m5kJfCOs4P+EvmC+v/lNWCpVDRFBHuQ6srSHjeen/fk=	2016-04-13 18:24:49.927495+00	t	f	Marni Springer	312-218-9884	\N	f
139	carleyfreeman@example.com	pbkdf2_sha256$24000$VJeo2lztQ5Gq$Vz8Rk70iT88MDQUYn++YCyvej0lq6HXvP4ozj6YFp4Q=	2016-04-18 00:20:52.09627+00	t	f	Carley Freeman	6305441074	\N	f
130	elizabethbelgio@example.com	pbkdf2_sha256$24000$hfCnuqsEFrkP$3sgLNzHPWIH586JVvcPOHQe6wjbdMD+GspnHeOgl8Zk=	2016-04-14 00:41:52.285298+00	t	f	Elizabeth Belgio	630-205-0388	\N	f
64	laura.thorne@comcast.net	pbkdf2_sha256$24000$I7676csFzZr1$iR8zHLoZQY1gXQKMr2GKaXfw9k1HmgK8SG8R2X89Omg=	2016-04-17 18:07:12.410857+00	t	f	Laura Thorne	630.405.9294	\N	f
150	amywagner@example.com	pbkdf2_sha256$24000$RonlDVg4fzyR$2CuaQvBpDXtEB9cHvzSbpj4u6sy0hQVe4A1nt1iUhe8=	2016-04-14 02:00:57.301522+00	t	f	Amy Wagner	773-620-9721	\N	f
140	melissalavigne@example.com	pbkdf2_sha256$24000$Ac5gfEaVTszu$z9OWkGnh7q2D4eTgl5XQCD6UPIKIsvCbKxSavHrCm1Q=	2016-04-14 01:20:52.194246+00	t	f	Melissa Lavigne	630-841-3577	\N	f
131	eunicechaney@example.com	pbkdf2_sha256$24000$Y7TdmdqlFelB$gMeYy8SaOtehTFb7qIiLdRABhw/IDzweaVq9jbzRWyY=	2016-04-14 00:44:20.864991+00	t	f	Eunice Chaney	773-485-8502	\N	f
142	paulinemoffett@example.com	pbkdf2_sha256$24000$YRZnD3Cv3rgx$0580vxJ8YTX4rgoNLDXNc2f1tS8BoCwtdRFQwylutc8=	2016-04-14 01:28:55.763998+00	t	f	Pauline Moffett	708-306-5307	\N	f
132	kerrryedwards@example.com	pbkdf2_sha256$24000$gJPWsjfBLPgd$Z3JfCm0wMCKlBP7JS+nKQLuFjm9pTx3lOo1st+mGT3Y=	2016-04-14 00:50:42.363247+00	t	f	Kerry Edwards	630-210-1309	\N	f
174	irmasims@example.com	pbkdf2_sha256$24000$P38x0TU4wE2u$VoBRy3b4DXUsAPqtblmYrWtfsEoLvi9p5XeZarA2Ccg=	2016-04-18 01:34:48.047524+00	t	f	\N	\N	\N	f
151	emilykeiner@example.com	pbkdf2_sha256$24000$PsuRTboSTzD6$WA5Z/KIp7rex2UxqPkzi8aGrOSVSkppouwyIOWevJIQ=	2016-04-14 02:02:58.752165+00	t	f	Emily Keiner	630	\N	f
143	sarahaumesser@example.com	pbkdf2_sha256$24000$wcvtKmK3keN8$JTZfs5KP3Eyur56e6FJkceJ6uWBiIaI8S6RzhWdle8k=	2016-04-14 01:34:33.936718+00	t	f	Sara Haumesser	630	\N	f
167	debshea@example.com	pbkdf2_sha256$24000$Mz9AN9zCa7Ur$+HJPgPCK6UDrwKpRa7N5WsOa5/8ln1vaoBUSoLyJ+do=	2016-04-17 18:40:32.243856+00	t	f	Deb Shea	630-420-6353	\N	f
158	miami_fan_lisa@yahoo.com	pbkdf2_sha256$24000$PtY7U1Fca1X0$qlBcgyrj/VvGQaMN9zFXpSUub9jcAauH6ECVUAcQUxo=	2016-04-14 11:21:59.611122+00	t	f	Lisa Nichols	630-677-3187	\N	f
147	miriamsen@example.com	pbkdf2_sha256$24000$YtE2C1nEpBGZ$gyOdjeb3FHKUVVYgD4n7b6TZcG/z6vl9YKb83dePvdw=	2016-04-14 01:50:24.618312+00	t	f	Miriam Sen	630-408-3350	\N	f
175	sttims@example.com	pbkdf2_sha256$24000$tktFWR0cQCV1$289tmJ/aLl4AY8/1R2OzFpWUwTGVRDhipggsRrHqTOA=	2016-04-18 01:42:31.947918+00	t	f	St. Tims Church	630	\N	f
168	celinasimon@example.com	pbkdf2_sha256$24000$Dcj5rNNP9UjP$gvZfCV/7bhMnCzny6EculSYed1H9TA/DrlPzNPmVpuw=	2016-04-17 18:48:07.311811+00	t	f	Celina Simon	630-420-6353	\N	f
148	beckyheusner@example.com	pbkdf2_sha256$24000$JZku1oANrDj8$DKY6MEdYYvlGNknMZ+zc6t1x2/e0ejsT+ppO68FCEnc=	2016-04-14 01:58:29.036055+00	t	f	Becky Heusner	6307500340	\N	f
133	janeenengle@example.com	pbkdf2_sha256$24000$BLsG44PHD68D$Pa5IEvIgz6cXarkOIiM1aaLXfaKJHCbirTk2pjRrz+8=	2016-04-14 00:55:16.84996+00	t	f	Janeen Engle	630-219-3478	\N	f
118	cindyboyer@example.com	pbkdf2_sha256$24000$3FbOSMWyeWnb$6xmkMNWLHJTyq5elThLb6Yz5kV+iyK7s2iBBMJrnCYo=	2016-04-18 01:00:49.038057+00	t	f	Cindy Boyer	6308545198	Any time	t
141	karenfalconio@example.com	pbkdf2_sha256$24000$WqclCffLNOz3$9GqlIPrwQo2/YxxkIlEaJHmlFVra6GCLKxeZNEagh/w=	2016-04-18 01:17:37.694341+00	t	f	Karen Falconio/ Doris Bender	630	\N	f
152	irmamebane-sims@example.com	pbkdf2_sha256$24000$dhm41fVGX4pS$RpFCBarB9ngWtU29ssODKdqv4xEqUw9Ej1ogSQl6Wko=	2016-04-18 01:35:15.859674+00	t	f	Irma Mebane-Sims	6308579246	9-12	t
134	jimferguson@example.com	pbkdf2_sha256$24000$YTJfCjOgZZju$9nxM0ADD6ZsMOr+Ml961KmrSFdPr+XFtWKr5B2VdxK8=	2016-04-14 00:57:29.863617+00	t	f	Jim Ferguson	412-606-5013	\N	f
163	laurathorne@example.com	pbkdf2_sha256$24000$UlsKVv3QZLO7$BLYtB2e9ntslwW1rm+D+FyijsNhMf73Er9IXNomhoZI=	2016-04-17 18:15:19.596935+00	t	f	Laura Thorne	630-548-2285	\N	f
164	melissabramwell@example.com	pbkdf2_sha256$24000$L8xcDD0hnMS1$xCNgHDB+Y1HjCd3CLJ3kz9Ef60cRLzWmoLQuSfWp4JY=	2016-04-17 18:17:54.362002+00	t	f	Melissa Bramwell	630-369-4341	\N	f
159	tonyaschmidt@example	pbkdf2_sha256$24000$fqPkKoKpWXNO$EX01vUnO0/NlPmpgVJDeOYmE3UOImH60wplco0RKmkg=	2016-04-14 18:40:01.707202+00	t	f	Derek Kraus	\N	\N	f
149	annsmith@example.com	pbkdf2_sha256$24000$ewudS0VdJ6Et$9EwC3Y8baXdQyypoDVQEOqluK+A7KYoHxaqw068jWwM=	2016-04-14 01:56:18.314493+00	t	f	Ann Smith	630-542-4901	\N	f
176	pattimurray@example.com	pbkdf2_sha256$24000$uWLPCcris9AF$4Onxk7qmEzVIyaxZtbb5KJ4xfgNrFY2dRYYqODTREDA=	2016-04-18 13:28:54.09498+00	t	f	Patti Murray (Sarah)	6304281322	\N	f
169	amyswiatek@example.com	pbkdf2_sha256$24000$fmChYxqGBC6g$DJFRyckYs3rZsosE5ZRy1Ql89ECWzKRLW2aSiG90BvE=	2016-04-17 18:58:12.011963+00	t	f	Amy Swiatek	847-858-6806	\N	f
119	mkloog@gmail.com	pbkdf2_sha256$24000$2gGo6oYjrxy5$VTwt67Q+OKZLO0EQQtwJQnv+Vnz3W/bvpuDMNy2oAyY=	2016-04-13 21:28:34.868565+00	t	f	melissa siomos	630-430-5941	\N	f
153	tonyaschmidt@example.com	pbkdf2_sha256$24000$XOxyb4dXLvgj$toZNfsmLwfr08sG796MuJCBCNu8ScCCi2XIxMNvgGgc=	2016-04-18 00:10:48.670608+00	t	f	Tonya Schmidt	6308533321	\N	f
160	nancybrown@example.com	pbkdf2_sha256$24000$uMKWcnIf3Tao$6GSSeCJzGnp1DhyklUvd4RSTdsE3+iTqXO2yeNPFx8U=	2016-04-18 00:19:37.67145+00	t	f	\N	\N	\N	f
135	tyrahawkins@example.com	pbkdf2_sha256$24000$UpfCh9SD0G7t$uvv1ar8v9BOybJodDbZ/IIxhIQS1pgQ0vFwSwZtIXng=	2016-04-14 01:03:30.784912+00	t	f	Tyra Hawkins	908-723-7544	\N	f
144	bevnewsome@example.com	pbkdf2_sha256$24000$EEA5OjPWg3VR$u8U07iYLDADaHbKyeMRd2ratL9VK1/4vAxk3Eewx71Y=	2016-04-14 01:36:33.183622+00	t	f	Bev Newsome	708-598-0651	\N	f
165	susanleesley@example.com	pbkdf2_sha256$24000$xh9RsuDo5jq8$ZSDe3kvwdBzXwId3YEQMoJqSB9mGYCIkT1ogz1btn6M=	2016-04-17 18:25:46.633123+00	t	f	Susan Leesley	630-267-1514	\N	f
154	mayashah@example.com	pbkdf2_sha256$24000$D9SiGlotVhEz$IZ3nWebK9z8xQsRJbDs3i8EZG4ylkXP6qYsM6PVBqUE=	2016-04-14 02:26:52.770951+00	t	f	Maya Shah	6304282882	\N	f
177	mariongibson@example.com	pbkdf2_sha256$24000$OiaW2L7yP63W$XkBZ7LYzTGJZ2TpTIqNP5FRwXTstAsbPXu+FAhirCdg=	2016-04-18 13:28:06.480492+00	t	f	Marion Gibson (Sarah)	6306642748	\N	f
170	joannwojtecki@example.com	pbkdf2_sha256$24000$inWqEPbj7wmm$YYwwsOgVGIpz38/+gBihWJPMjDkXZTVv47W+nc2LimM=	2016-04-17 19:02:21.833889+00	t	f	JoAnn Wojtecki	630-369-2974	\N	f
136	nancybrown@example	pbkdf2_sha256$24000$NB303H7cIshY$A+peJT/M+d7O0mLVvdgU94okPFFsYkYgpQGCNq9aTbA=	2016-04-14 01:05:22.518364+00	t	f	Nancy Brown	6305084142	All	t
178	amyrossi02@yahoo.com	pbkdf2_sha256$24000$U2Z7ELUpmofA$DMLj/J06hpoSUP+mwMajDMkspvaZfwNvevnGJdj3HRs=	2016-04-18 12:58:27.21043+00	t	f	Amy Rossi	630.399.8587	\N	f
137	jenniferjansen@example.com	pbkdf2_sha256$24000$oXPlImEvQn0k$sYvJB13hH9dFZTvSIZKE8PJJFIbNzvdm33HBU97Lv9Y=	2016-04-14 01:10:47.23226+00	t	f	Jennifer Jansen	630-341-5511	\N	f
166	laurienirtaut@example.com	pbkdf2_sha256$24000$xCkD9avIBakW$ZfR25XpNBrDKkJtt3f2sKPcu+ch8sfmRUTlnts1jJXg=	2016-04-17 18:36:19.307731+00	t	f	Laurie Nirtaut	630-369-7069	\N	f
155	amysimons@example.com	pbkdf2_sha256$24000$gfRpyc8Y6cXu$vtW4wH57JVEQ81u3YL/adqTz3CQ8wQb09kVSrH3r0sA=	2016-04-14 02:31:31.926276+00	t	f	Amy Simons	6303621212	\N	f
146	carenradek@example.com	pbkdf2_sha256$24000$D4mHxGl24mCB$zfy9njTl2Ew2eTKG9e4ZCSMR89hj4VFLBVM/R8Xb4xE=	2016-04-14 01:48:59.970037+00	t	f	Caren Radek	630-969-2102	\N	f
138	steveklepper@example.com	pbkdf2_sha256$24000$GrMMUQHQ5Suo$ebTh9waNtHoKfwWuiX4C9b0IwP3AxKVhgmceucBVKps=	2016-04-14 01:15:31.78413+00	t	f	Steve Klepper	630-362-3430	\N	f
120	sophiaxi@example.com	pbkdf2_sha256$24000$kgpba4a67idd$JkQhE4BSHez8RSPkAixc3tFkMWUkHz5L2R7pmTPiWF4=	2016-04-14 00:05:58.929698+00	t	f	Sophia Xi	630-390-0177	\N	f
156	cindysmucker@example.com	pbkdf2_sha256$24000$otUJXBt2KHI2$qvcsc46eWQ80ts0MyWisxK0Fj97nxydXvahC7CCOLYY=	2016-04-14 02:35:18.684443+00	t	f	Cindy Smuckeer	6304158174	\N	f
145	andreshernandez@example.com	pbkdf2_sha256$24000$7oaPF4bR5NLS$mXZS37Quiwz3f+lFVpJQhH5OHxhXnXu9tPyM7uHjJ/Y=	2016-04-14 02:36:53.839064+00	t	f	Andres Hernandez	630	\N	f
171	millstreetoffice@example.com	pbkdf2_sha256$24000$xLzjmuPvBnHG$qOy0CiEwSucl19c/anLu8S3IGbS9u10bhBJDKnLNuQs=	2016-04-17 19:07:53.069339+00	t	f	Mill Street Office	630-420-6353	\N	f
129	tracybaynard@example.com	pbkdf2_sha256$24000$hBXFNO3BJH6f$1TRe2QdutNxwcRl2tVTtbPKd9HHEvz+lc/5MGj6WIZM=	2016-04-14 00:10:34.188876+00	t	f	Tracy Baynard	630-548-3678	\N	f
157	meganwisniewski@example.com	pbkdf2_sha256$24000$jqD5kERXLlgO$1+inVWiJtWB0SHvZd7n3VxaLpKH2qAv7FBEwM9xChYg=	2016-04-14 02:40:48.316191+00	t	f	Megan Wisniewski	6303362526	\N	f
\.


--
-- Name: plants_stakeholder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docker
--

SELECT pg_catalog.setval('plants_stakeholder_id_seq', 179, true);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: plants_order_pkey; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY plants_order
    ADD CONSTRAINT plants_order_pkey PRIMARY KEY (id);


--
-- Name: plants_orderitem_pkey; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY plants_orderitem
    ADD CONSTRAINT plants_orderitem_pkey PRIMARY KEY (id);


--
-- Name: plants_plant_pkey; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY plants_plant
    ADD CONSTRAINT plants_plant_pkey PRIMARY KEY (id);


--
-- Name: plants_stakeholder_email_key; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY plants_stakeholder
    ADD CONSTRAINT plants_stakeholder_email_key UNIQUE (email);


--
-- Name: plants_stakeholder_pkey; Type: CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY plants_stakeholder
    ADD CONSTRAINT plants_stakeholder_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: docker
--

CREATE INDEX auth_group_name_a6ea08ec_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: docker
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: docker
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: docker
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: docker
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: docker
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: docker
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: docker
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: docker
--

CREATE INDEX django_session_session_key_c0390e0f_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: plants_order_7d3df739; Type: INDEX; Schema: public; Owner: docker
--

CREATE INDEX plants_order_7d3df739 ON plants_order USING btree (stakeholder_id);


--
-- Name: plants_orderitem_69dfcb07; Type: INDEX; Schema: public; Owner: docker
--

CREATE INDEX plants_orderitem_69dfcb07 ON plants_orderitem USING btree (order_id);


--
-- Name: plants_orderitem_815292a4; Type: INDEX; Schema: public; Owner: docker
--

CREATE INDEX plants_orderitem_815292a4 ON plants_orderitem USING btree (plant_id);


--
-- Name: plants_stakeholder_email_de693335_like; Type: INDEX; Schema: public; Owner: docker
--

CREATE INDEX plants_stakeholder_email_de693335_like ON plants_stakeholder USING btree (email varchar_pattern_ops);


--
-- Name: auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token_user_id_35299eff_fk_plants_stakeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_plants_stakeholder_id FOREIGN KEY (user_id) REFERENCES plants_stakeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_content_type_id_c4bce8eb_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_content_type_id_c4bce8eb_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_c564eba6_fk_plants_stakeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_plants_stakeholder_id FOREIGN KEY (user_id) REFERENCES plants_stakeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: plants_order_stakeholder_id_5af67d3a_fk_plants_stakeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY plants_order
    ADD CONSTRAINT plants_order_stakeholder_id_5af67d3a_fk_plants_stakeholder_id FOREIGN KEY (stakeholder_id) REFERENCES plants_stakeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: plants_orderitem_order_id_e2f39cc1_fk_plants_order_id; Type: FK CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY plants_orderitem
    ADD CONSTRAINT plants_orderitem_order_id_e2f39cc1_fk_plants_order_id FOREIGN KEY (order_id) REFERENCES plants_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: plants_orderitem_plant_id_3b6aae17_fk_plants_plant_id; Type: FK CONSTRAINT; Schema: public; Owner: docker
--

ALTER TABLE ONLY plants_orderitem
    ADD CONSTRAINT plants_orderitem_plant_id_3b6aae17_fk_plants_plant_id FOREIGN KEY (plant_id) REFERENCES plants_plant(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

